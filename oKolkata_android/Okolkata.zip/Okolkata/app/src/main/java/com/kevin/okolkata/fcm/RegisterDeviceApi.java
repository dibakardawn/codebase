package com.kevin.okolkata.fcm;

import retrofit2.Call;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface RegisterDeviceApi {
  //  private static String fcmregurl = "http://okolkata.in/admin/notification/notification.php?ACTION=REGISTERDEVICE&platForm=Andriod";

    @GET("/admin/notification/notification.php?ACTION=REGISTERDEVICE&platForm=Andriod")
    Call<TokenRegResponce> register(@Query("deviceId") String token);
}
