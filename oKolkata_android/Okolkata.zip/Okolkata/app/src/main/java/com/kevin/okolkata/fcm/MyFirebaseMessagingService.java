package com.kevin.okolkata.fcm;


import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import com.google.gson.Gson;
import com.kevin.okolkata.notificationUtil.NotificationHelper;
import com.kevin.okolkata.notificationUtil.SharedPrefsManager;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * NOTE: There can only be one service in each app that receives FCM messages. If multiple
 * are declared in the Manifest then the first one will be chosen.
 * <p>
 * In order to make this Java sample functional, you must remove the following from the Kotlin messaging
 * service in the AndroidManifest.xml:
 * <p>
 * <intent-filter>
 * <action android:name="com.google.firebase.MESSAGING_EVENT" />
 * </intent-filter>
 */
public class MyFirebaseMessagingService extends FirebaseMessagingService {

    private static final String TAG = "MyFirebaseMsgService";
    private Context context;

    /**
     * Called when message is received.
     *
     * @param remoteMessage Object representing the message received from Firebase Cloud Messaging.
     */

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {

        context = this;
        Log.d(TAG, "From: " + remoteMessage.getFrom());

        // Check if message contains a data payload.
        if (remoteMessage.getData().size() > 0) {
            Log.d(TAG, "Message data payload: " + remoteMessage.getData());
        }

        String json = remoteMessage.getData().get("body");
        Gson g = new Gson();
        NotificationPojo pojo  = g.fromJson(json, NotificationPojo.class);
        Bitmap bitmap = getBitmapfromUrl(pojo.getImage());
        NotificationHelper notificationHelper = new NotificationHelper(context);
        notificationHelper.showNotification(context, pojo.getUrl(),pojo.getMessage(),pojo.getHeadline(), bitmap);


    }

    /**
     * Called if InstanceID token is updated. This may occur if the security of
     * the previous token had been compromised. Note that this is called when the InstanceID token
     * is initially generated so this is where you would retrieve the token.
     */
    @Override
    public void onNewToken(String token) {
        context = this;
Log.v("token",token);
        sendRegistrationToServer(token);
    }


    /**
     * Persist token to third-party servers.
     * <p>
     * Modify this method to associate the user's FCM InstanceID token with any server-side account
     * maintained by your application.
     *
     * @param token The new token.
     */
    private void sendRegistrationToServer(String token) {
        // TODO: Implement this method to send token to your app server.
        saveToken(token);
    }

    public void saveToken(final String token) {


        RegisterDeviceApi service = new Retrofit.Builder()
                .baseUrl("http://okolkata.in/")
                //      .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(RegisterDeviceApi.class);

        retrofit2.Call<TokenRegResponce> mservice = service.register(token);

        mservice.enqueue(new Callback<TokenRegResponce>() {
            @Override
            public void onResponse(Call<TokenRegResponce> call, Response<TokenRegResponce> response) {
                if (response.code() == 200) {
                    SharedPrefsManager prefsManager = new SharedPrefsManager(context);
                    prefsManager.saveToken(token);
                }
            }

            @Override
            public void onFailure(Call<TokenRegResponce> call, Throwable t) {

            }
        });
    }

    /*
     *To get a Bitmap image from the URL received
     * */
    public Bitmap getBitmapfromUrl(String imageUrl) {
        try {
            URL url = new URL(imageUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setDoInput(true);
            connection.connect();
            InputStream input = connection.getInputStream();
            Bitmap bitmap = BitmapFactory.decodeStream(input);
            return bitmap;

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            return null;

        }
    }

}