package com.kevin.okolkata;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.kevin.okolkata.fcm.RegisterDeviceApi;
import com.kevin.okolkata.fcm.TokenRegResponce;
import com.kevin.okolkata.notificationUtil.NotificationHelper;
import com.kevin.okolkata.notificationUtil.SharedPrefsManager;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MainActivity extends AppCompatActivity {
    private static String baseUrl = "http://okolkata.in/";
    private ProgressBar progressBar;
    private WebView webView;
    private SharedPrefsManager sharedPrefsManager;
    private boolean shouldDisplayLoader=true;
    private  boolean splashDisplayed=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setProgressBarVisibility(View.VISIBLE);
        webView = findViewById(R.id.webview);
        progressBar = findViewById(R.id.progress_circular);
        sharedPrefsManager = new SharedPrefsManager(this);
        firebaseTokenInit();

        if (getIntent().getStringExtra("url") != null) {
            splashDisplayed=false;
            loadWeb(getIntent().getStringExtra("url"));
        } else
            loadWeb(baseUrl);
    }

    private void firebaseTokenInit() {
        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            return;
                        }
                        // Get new Instance ID token
                        String token = task.getResult().getToken();
                        if (!sharedPrefsManager.isTokenUpdateinServer(token)) {
                            saveToken(token);
                        } else Log.d("token status", "already saved");
                    }
                });
    }


    public void loadWeb(String url) {
        webView.getSettings().setBuiltInZoomControls(false);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setCacheMode(WebSettings.LOAD_CACHE_ELSE_NETWORK);
        webView.getSettings().setAppCacheEnabled(true);
        webView.setWebViewClient(new WebViewClient() {

            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if(request.getUrl().getPath().contains("post")) {
                    shouldDisplayLoader=false;

                }else{
                        shouldDisplayLoader=true;
                }
                return super.shouldOverrideUrlLoading(view, request);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return super.shouldOverrideUrlLoading(view, url);
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                super.onPageStarted(view, url, favicon);
                showLoader();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                hideLoader();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                hideLoader();
            }
        });

        webView.loadUrl(url);
    }

    private void setProgressBarVisibility(int visibility) {
        // If a user returns back, a NPE may occur if WebView is still loading a page and then tries to hide a ProgressBar.
        if (progressBar != null) {
            progressBar.setVisibility(visibility);
        }
    }


    public void saveToken(final String token) {

        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder().addInterceptor(interceptor).build();

        RegisterDeviceApi service = new Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(RegisterDeviceApi.class);

        retrofit2.Call<TokenRegResponce> mservice = service.register(token);

        mservice.enqueue(new Callback<TokenRegResponce>() {
            @Override
            public void onResponse(Call<TokenRegResponce> call, Response<TokenRegResponce> response) {
                if (response.code() == 200)
                    sharedPrefsManager.saveToken(token);
            }

            @Override
            public void onFailure(Call<TokenRegResponce> call, Throwable t) {

            }
        });
    }
    @Override
    public boolean onKeyDown(final int keyCode, final KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    void showLoader()
    {
       if(!splashDisplayed)
        {
            splashDisplayed=true;
            if (shouldDisplayLoader) {
                setProgressBarVisibility(View.VISIBLE);
            } else {
                hideLoader();
            }
        }
       else {
               hideLoader();
       }
    }


    void hideLoader()
    {
        setProgressBarVisibility(View.GONE);

    }
}
