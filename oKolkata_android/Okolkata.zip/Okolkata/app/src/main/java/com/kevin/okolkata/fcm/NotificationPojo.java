package com.kevin.okolkata.fcm;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NotificationPojo {
    @SerializedName("image")
    @Expose
    private String image;
    @SerializedName("title")
    @Expose
    private String headline;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("subtitle")
    @Expose
    private String subtitle;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getHeadline() {
        return headline;
    }

    public void setHeadline(String headline) {
        this.headline = headline;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getUrl() {
        return subtitle;
    }

    public void setUrl(String url) {
        this.subtitle = url;
    }
}
