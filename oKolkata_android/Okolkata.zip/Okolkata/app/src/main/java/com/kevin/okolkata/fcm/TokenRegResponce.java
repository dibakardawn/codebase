package com.kevin.okolkata.fcm;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class TokenRegResponce {
    @SerializedName("successCode")
    @Expose
    private Integer successCode;

    public Integer getSuccessCode() {
        return successCode;
    }

    public void setSuccessCode(Integer successCode) {
        this.successCode = successCode;
    }
}


