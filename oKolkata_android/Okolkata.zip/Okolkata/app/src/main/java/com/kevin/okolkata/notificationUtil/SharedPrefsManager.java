package com.kevin.okolkata.notificationUtil;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPrefsManager {

    private SharedPreferences preferences;
    private String prefsKey="okolkata_prefs_key";
    private String tokenKey="token_key";

    public SharedPrefsManager(Context context) {
        this.preferences = context.getSharedPreferences(prefsKey, Context.MODE_PRIVATE);
    }

    public  void saveToken(String token)
    {
        SharedPreferences.Editor editor= preferences.edit();
        editor.putString(tokenKey,token);
        editor.apply();
    }

    public String getToken(){
        return preferences.getString(tokenKey,null);
    }

    public boolean isTokenUpdateinServer(String token){
        if (getToken()==null)
            return false;
        return getToken().equals(token);
    }

}
