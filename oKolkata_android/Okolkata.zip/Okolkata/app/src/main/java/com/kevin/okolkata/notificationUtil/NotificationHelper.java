package com.kevin.okolkata.notificationUtil;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.RemoteMessage;
import com.google.gson.Gson;
import com.kevin.okolkata.MainActivity;
import com.kevin.okolkata.R;
import com.kevin.okolkata.fcm.NotificationPojo;


public class NotificationHelper {


    private Context mContext;


    public NotificationHelper(Context context) {
        mContext = context;
    }


    public void showNotification(Context context, String url,String message,String headline, Bitmap bitmap) {




        mContext = context;
        Intent intent = new Intent(mContext, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        intent.putExtra("url",url);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                        | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(mContext, 0, intent, PendingIntent.FLAG_ONE_SHOT);
        NotificationCompat.Builder notificationBuilder;
        notificationBuilder = new NotificationCompat.Builder(mContext, "Okoltata notification")
                .setSmallIcon(R.drawable.logo)
                .setContentTitle(headline)
                .setContentText(message)
                .setDefaults(Notification.DEFAULT_ALL)
                .setAutoCancel(true)
                .setLargeIcon(BitmapFactory.decodeResource(context.getResources(),
                        R.drawable.logo))
                .setStyle(new NotificationCompat.BigTextStyle()
                        .bigText(headline))
                        .setStyle(new NotificationCompat.BigPictureStyle()
                        .bigPicture(bitmap))//Notification with Image
                .setAutoCancel(true)
                .setTicker(headline)
                .setWhen(System.currentTimeMillis())
                .setContentIntent(pendingIntent);

        NotificationManager mNotificationManager = (NotificationManager) mContext.getSystemService(Context.NOTIFICATION_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            // Changing Default mode of notification
            notificationBuilder.setDefaults(Notification.DEFAULT_ALL);
            // Creating Channel
            NotificationChannel notificationChannel = new NotificationChannel("Okoltata notification", "Okoltata notification", NotificationManager.IMPORTANCE_HIGH);
            assert mNotificationManager != null;
            mNotificationManager.createNotificationChannel(notificationChannel);

        }
        mNotificationManager.notify((int)System.currentTimeMillis(), notificationBuilder.build());

    }

}