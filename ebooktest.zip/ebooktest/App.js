import React, { useState } from "react";
import { Platform,PermissionsAndroid} from 'react-native';
import { ReactReader } from "react-reader"; // https://www.npmjs.com/package/react-reader
import AWS from 'aws-sdk/dist/aws-sdk-react-native'; //npm install aws-sdk

const App = () => {
	// And your own state logic to persist state
	const [location, setLocation] = useState(null);
	const locationChanged = (epubcifi) => {
		// epubcifi is a internal string used by epubjs to point to a location in an epub. It looks like this: epubcfi(/6/6[titlepage]!/4/2/12[pgepubid00003]/3:0)
		setLocation(epubcifi)
	};
	const [epubUrl, setEpubUrl] = useState("https://s3.amazonaws.com/epubjs/books/moby-dick/OPS/package.opf");
	//let state = { epubUrl: "https://s3.amazonaws.com/epubjs/books/moby-dick/OPS/package.opf" };
	const s3 = new AWS.S3({
		region: 'ap-south-1',
		credentials: {
			accessKeyId: 'AKIA3SYKMXCM7AIN6OXM',
			secretAccessKey: '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'
		}
	});
	const params = {Bucket: 'okolkataebooks', Key: 'sukumarray_pri.epub'};
		s3.getSignedUrl('getObject', params, function (err, authUrl) {
		console.log('Your generated pre-signed URL is', authUrl);
		//setState({ epubUrl: authUrl });
		//http://localhost:19006/ebookfiles/sukumarray_pri.epub
		setEpubUrl(authUrl);
		downloadBlob(authUrl, 'sukumarray_pri.epub')
	});
	
	function downloadBlob(blob, name) {
		// Convert your blob into a Blob URL (a special url that points to an object in the browser's memory)
		//const blobUrl = window.URL.createObjectURL(blob);
		// Create a link element
		const link = document.createElement('a');
		// Set link's href to point to the Blob URL
		link.href = blob;
		link.download = name;
		// Append link to the body
		document.body.appendChild(link);
		// Dispatch click event on the link
		// This is necessary as link.click() does not work on the latest firefox
		link.dispatchEvent(
		new MouseEvent('click', {
			  bubbles: true,
			  cancelable: true,
			  view: window,
		})
	);

	// Remove link from body
	document.body.removeChild(link);
	}
	
	return (
		<div style={{ height: "100vh" }}>
		  <ReactReader
			location={location}
			locationChanged={locationChanged}
			url={epubUrl}
		  />
		</div>	
	)
}

export default App