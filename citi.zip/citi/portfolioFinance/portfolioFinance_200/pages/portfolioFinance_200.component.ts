import { Component, OnInit, HostBinding, Inject } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ContentService, ILoggerService, AppStore } from '@citi-gcg-167407/core-services';
import { routeAnimation, BaseComponent, AnimationService, SessionExtService, CitiWindow, WINDOW, CommonService, AppSourceType, CordovaService, GlobalConfig, DeeplinkService, AppConstantsService, IAnalyticsEngine, AnalyticsType, GmHelpersService } from '@citi-gcg-167407/common';
import { AppService } from 'src/app/app.service';
import { forkJoin } from 'rxjs';

import {
  customerRelationship,
  CustomerRelationshipListResponse,
  creditFacilityDetails,
  RetrieveCreditFacilityFulfillmentArrangementSummaryResponse,
  RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetailsResponse,
  piChartObj,
  primaryBSLinkItem,
  primaryBScontentMapper
} from '../../models/portfolioFinance';
import { portfolioFinanceConstants } from '../../models/portfolioFinanceConstants';
import { portfolioFinanceAPIService } from '../../services/portfolioFinance-API.Service';
import { portfolioFinanceCommonService } from '../../services/portfolioFinance-Common.service';

@Component({
  selector: 'portfolioFinance_200',
  templateUrl: './portfolioFinance_200.component.html',
  styleUrls: ['./portfolioFinance_200.component.scss'],
  animations: [routeAnimation]
})
export class portfolioFinance200Component extends BaseComponent implements OnInit {
  @HostBinding('@routing') public routing;
  public isDeepLink: boolean = false;
  public animationServiceEventsSubscription: any;
  public portfolioFinance200ContentData: any;
  public portfolioFinance300ContentData: any;
  public portfolioFinance350ContentData: any;
  public functionsEligible: any;
  public customerRelationshipList: CustomerRelationshipListResponse;
  public selectedCustomerRelationshipProfile: customerRelationship;
  public creditFacilityFulfillmentArrangementSummary: RetrieveCreditFacilityFulfillmentArrangementSummaryResponse;
  public selectedCreditFacilityFulfillmentArrangementProfile: creditFacilityDetails;
  public RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails: RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetailsResponse;
  public defalutRelationshipTypes: string[] = portfolioFinanceConstants.defalutRelationshipTypes;
  public hasLoanDetails: boolean = false;
  public hasCreditLimitDetails: boolean = false;
  public downBtnSVG: string = '';
  public multiUserBtnSVG: string = '';
  public blueCheckIcon: string = '';
  public nextIcon: string = '';
  public infoImg: string = '';
  public faqImg: string = '';
  public exclamatorySVG: string = '';
  public cashFlowIcon: string = '';
  public interestRateIcon: string = '';
  public additionalCashIcon: string = '';
  public fxCurrencyIcon: string = '';
  public flexibleTenureIcon: string = '';
  public timeDepositIcon: string = '';
  public pdfIcon: string = '';
  public piChartObj: piChartObj;
  public piChartRadius: number = 65;
  public piChartStartArcColors: string = '#a89f69';
  public piChartendArcColors: string = '#6b5019';
  public piChartArcThikness: number = 10;
  public selectRelationshipBS: boolean = false;
  public primaryBS: boolean = false;
  public primaryBSContent: primaryBScontentMapper;
  public primaryBSLinkContent: primaryBSLinkItem;
  public displayOutStandingLoanOnPrimaryBS = false;
  public displayCreditLimitOnPrimaryBS = false;
  public localCurrency: string;
  public seconderyBS: boolean = false;
  public SeconderyBSIndex: number = 0;
  public portfolioFinanceCSVEnable: boolean = false;
  public portfolioFinanceCountryCode: string = "";
  public linkBS: boolean = false;
  public linkBSHeight: string = '75.56vh';
  public linkBSHeaderText: string = '';
  public linkBSBodyText: string = '';
  public apiErrorBS: boolean = false;
  public apiErroPage: boolean = false;
  public displayProductMarketSpace: boolean = false;
  public customerSegment: string = '';
  public goldnAboveCustomerFlag: boolean = false;
  public displaySpinner: boolean = false;
  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private animationService: AnimationService,
    private contentService: ContentService,
    private commonService: CommonService,
    private appService: AppService,
    private cordovaService: CordovaService,
    private appStore: AppStore,
    private deeplinkService: DeeplinkService,
    private portfolioFinanceAPIService: portfolioFinanceAPIService,
    private portfolioFinanceCommonService: portfolioFinanceCommonService,
    sessionExtService: SessionExtService,
    private appConst: AppConstantsService,
    @Inject(WINDOW) private win: CitiWindow,
    @Inject('ILoggerService') oLogger: ILoggerService,
    @Inject('IAnalyticsEngine') private analyticsEngine: IAnalyticsEngine,
    private gmHelperService: GmHelpersService
  ) {
    super(oLogger, sessionExtService);
  }

  ngOnInit() {
    this.routing = this.animationService.animationDirection();
    this.animationServiceEventsSubscription = this.animationService.emitCurrentDirection.subscribe((direction: any) => {
      this.routing = direction;
    });
    if (this.route.snapshot.queryParamMap.get('isDeepLink') === "true") {
      this.isDeepLink = true;
    }

    this.portfolioFinance200ContentData = this.contentService.getContentFromStore('portfolioFinance', 'portfolioFinance', 'portfolioFinance_200');
    this.localCurrency = this.portfolioFinance200ContentData.localCurrency;
    this.portfolioFinance300ContentData = this.contentService.getContentFromStore('portfolioFinance', 'portfolioFinance', 'portfolioFinance_300');
    this.portfolioFinance350ContentData = this.contentService.getContentFromStore('portfolioFinance', 'portfolioFinance', 'portfolioFinance_350');

    this.functionsEligible = this.appStore.getGlobalConfig<GlobalConfig>().functionsEligible;
    if (typeof (this.functionsEligible.portfolioFinanceCSVEnable) !== 'undefined' && this.functionsEligible.portfolioFinanceCSVEnable !== null) {
      this.portfolioFinanceCSVEnable = this.functionsEligible.portfolioFinanceCSVEnable;
    }
    this.portfolioFinanceCountryCode = this.commonService.countryCode;

    this.downBtnSVG = this.appService.getAsset('icons/c-chevron-down.svg');
    this.multiUserBtnSVG = this.appService.getAsset('icons/c-24-profile-team.svg');
    this.blueCheckIcon = this.appService.getAsset('icons/circle_check_blue.svg');
    this.nextIcon = this.appService.getAsset('icons/c-chevron-right.svg');
    this.infoImg = this.appService.getAsset('icons/c-16-information.svg');
    this.faqImg = this.appService.getAsset('icons/c-16-question.svg');
    this.exclamatorySVG = this.appService.getAsset('icons/c-fields-error-red.svg');

    this.cashFlowIcon = this.appService.getAsset('icons/c-24-send-funds.svg');
    this.interestRateIcon = this.appService.getAsset('icons/c-24-bar-chart.svg');
    this.additionalCashIcon = this.appService.getAsset('icons/c-24-pie-chart.svg');
    this.fxCurrencyIcon = this.appService.getAsset('icons/c-24-fx-exchange.svg');
    this.flexibleTenureIcon = this.appService.getAsset('icons/c-24-recurring.svg');
    this.timeDepositIcon = this.appService.getAsset('icons/c-24-buy-stock.svg');
    this.pdfIcon = this.appService.getAsset('icons/c-20-document-pdf.svg');

    this.displaySpinner = true;
    forkJoin(
      this.portfolioFinanceAPIService.getCustomerRelationshipList(),
      this.portfolioFinanceAPIService.getRetrieveCreditFacilityFulfillmentArrangementSummaryResponse()
    ).subscribe(([CRL_response, CFFAS_response]) => {
      this.customerRelationshipList = CRL_response;
      this.creditFacilityFulfillmentArrangementSummary = CFFAS_response;
      if (CRL_response) {
        if (CFFAS_response) {
          this.mapScreenData();
          this.callsiteCatalyst('PF200LANDING');
          this.callsiteCatalyst('PF200SINGLEMULTIRELATIONLOAD');
        } else {
          this.selectCustomerRelationshipProfile();
          this.displayProductMarketSpace = true;
          this.checkIfUserIsGoldnAbove();
        }
      } else {
        this.displayApiFailure();
      }

      this.displaySpinner = false;
    }, (error) => {
      this.displaySpinner = false;
      this.displayApiFailure();
    });
  }

  ngAfterViewInit() {
    try {
      /*-------------------------------------Deeplinked module--------------------------------*/
      const isRequestedDeeplink = this.deeplinkService.isRequestedDeeplink('PORTFOLIOFINANCE');
      if (isRequestedDeeplink) {
        this.appService.showWebView(500).subscribe();
        this.deeplinkService.clearSelection();
      }
      /*-------------------------------------Deeplinked module--------------------------------*/
    } catch (e) {
      //console.log("Error @ngAfterViewInit");
    }
  }

  public selectCustomerRelationshipProfile() {
    let relationshipId: string = this.portfolioFinanceCommonService.relationshipId;
    if (relationshipId === '') {
      for (let i = 0; i < this.customerRelationshipList.customerRelationship.length; i++) {
        if (this.defalutRelationshipTypes.indexOf(this.customerRelationshipList.customerRelationship[i].relationshipType) > -1) {
          this.selectedCustomerRelationshipProfile = this.customerRelationshipList.customerRelationship[i];
          this.portfolioFinanceCommonService.relationshipId = this.customerRelationshipList.customerRelationship[i].relationshipId;
          break;
        }
      }
    } else {
      for (let i = 0; i < this.customerRelationshipList.customerRelationship.length; i++) {
        if (this.customerRelationshipList.customerRelationship[i].relationshipId === relationshipId) {
          this.selectedCustomerRelationshipProfile = this.customerRelationshipList.customerRelationship[i];
          this.portfolioFinanceCommonService.relationshipId = relationshipId;
          break;
        }
      }
    }
  }

  public mapScreenData() {
    this.selectCustomerRelationshipProfile();
    for (let j = 0; j < this.creditFacilityFulfillmentArrangementSummary.creditFacilityDetails.length; j++) {
      if (this.creditFacilityFulfillmentArrangementSummary.creditFacilityDetails[j].relationshipId === this.portfolioFinanceCommonService.relationshipId) {
        this.selectedCreditFacilityFulfillmentArrangementProfile = this.creditFacilityFulfillmentArrangementSummary.creditFacilityDetails[j];
        break;
      }
    }
    if (typeof this.selectedCreditFacilityFulfillmentArrangementProfile !== 'undefined' && this.selectedCreditFacilityFulfillmentArrangementProfile.portfolioPowerFlag) {
      let effectiveUtilPercent: number;
      //--------------AW-6159 Logic------------------
      if (this.selectedCreditFacilityFulfillmentArrangementProfile.availableAmount === 0 || this.selectedCreditFacilityFulfillmentArrangementProfile.utilizationPercent > 100) {
        effectiveUtilPercent = 0.00;
      } else {
        effectiveUtilPercent = +(100 - +(this.selectedCreditFacilityFulfillmentArrangementProfile.utilizationPercent.toFixed(2)));
      }
      effectiveUtilPercent = +(effectiveUtilPercent.toFixed(2));
      //--------------AW-6159 Logic------------------
      this.piChartObj = {
        percent: effectiveUtilPercent,
        radius: this.piChartRadius,
        startArcColors: this.piChartStartArcColors,
        endArcColors: this.piChartendArcColors,
        arcThikness: this.piChartArcThikness,
        piChartText: this.portfolioFinance200ContentData.Txt_PortfolioFinanceChart_Available
      }
      this.displaySpinner = true;
      this.portfolioFinanceAPIService.getRetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetailsResponse(this.portfolioFinanceCommonService.relationshipId).subscribe((CFFACOLD_response) => {
        if (CFFACOLD_response) {
          this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails = CFFACOLD_response;
          if (typeof (this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.loanDetails) !== 'undefined') {
            this.hasLoanDetails = true;
          }
          if (typeof (this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.collateralDetails) !== 'undefined') {
            this.hasCreditLimitDetails = true;
          }
        } else {
          this.displayApiFailureBS();
        }

        this.displaySpinner = false;
      }, (error) => {
        this.displaySpinner = false;
        this.displayApiFailureBS();
      });
    } else {
      //Obsolated logic #4933
      this.displayProductMarketSpace = true;
      this.checkIfUserIsGoldnAbove();
    }
  }

  public gotoWealthDashboard(e: TouchEvent) {
    if (this.isDeepLink) {
      this.appService.deepDropToOdysseyDashboard();
    } else {
      if (this.commonService.isOdysseyFlow) {
        this.appService.backToOdyssey();
      } else if (this.commonService.isDvpFlow) {
        this.appService.backToDvp();
      } else if (this.commonService.appSource === AppSourceType.MRC_NATIVE) {
        this.appService.backNative(true);
        this.commonService.clearActiveLaunchMenu();
      } else {
        this.cordovaService.gmDisplaySplashScreen(
          {},
          () => {
            this.commonService.executeGMAndReturnVoid({
              signature: 'GM.globalNav.HomeIconClick',
            });
          },
          () => this.cordovaService.gmClearSplashScreen(),
          true
        );
      }
    }
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
  }

  public getRelationshipTitle() {
    let relationShipTitle: string = "";
    if (typeof (this.selectedCustomerRelationshipProfile) !== 'undefined') {
      if (this.selectedCustomerRelationshipProfile.relationshipTitle !== "") {
        relationShipTitle = this.selectedCustomerRelationshipProfile.relationshipTitle;
      }
    } else {
      for (let i = 0; i < this.customerRelationshipList.customerRelationship.length; i++) {
        if (this.defalutRelationshipTypes.indexOf(this.customerRelationshipList.customerRelationship[i].relationshipType) > -1) {
          relationShipTitle = this.customerRelationshipList.customerRelationship[i].relationshipTitle;
          break;
        }
      }
    }
    return relationShipTitle;
  }

  public reLoadPage(e: TouchEvent, relationshipId: string) {
    this.closeSelectRelationshipBS(e);
    this.portfolioFinanceCommonService.relationshipId = relationshipId;
    this.animationService.routingService('upward', this.router.url, '../portfolioFinance/portfolioFinance_800', {
      queryParams: {}
    });
  }

  public checkIfUserIsGoldnAbove() {
    try {
      this.customerSegment = this.appStore.getCustomerProfile().accountSummary.brandingType;
      if (this.customerSegment !== null) {
        if (this.customerSegment === 'CitiGold') {
          this.goldnAboveCustomerFlag = true;
        } else if (this.customerSegment === 'CitiBlue') {
          setTimeout(() => {
            this.goldnAboveCustomerFlag = false;
          }, 0);
        }
      }
    } catch (e) {
    }

    if (this.goldnAboveCustomerFlag) {
      this.callsiteCatalyst('PF200MARKETINGSPACE');
    } else {
      this.callsiteCatalyst('PF200ERRSENARIO', this.portfolioFinance200ContentData.Err_NonCitiGoldPF_Text);
    }
  }

  public openSelectRelationshipBS(e: Event) {
    this.selectRelationshipBS = true;
    this.callsiteCatalyst('PF200SELECTRELATION');
  }

  public closeSelectRelationshipBS(e: Event) {
    this.selectRelationshipBS = false;
  }

  public emitClickOutsideToCloseselectRElationshipBS(e) {
    this.selectRelationshipBS = e;
  }

  public openPrimaryBS(e: Event, identifier: string) {
    if (identifier === 'OUTSTANDINGLOAN') {
      this.primaryBSContent = {
        header: this.portfolioFinance300ContentData.Txt_PortfolioFinance_OutstandingLoan,
        tooltipContent: '',
        lebel: this.portfolioFinance300ContentData.Txt_OutstandingLoan_TotalAmount,
        currency: this.selectedCreditFacilityFulfillmentArrangementProfile.currencyCode,
        amount: +((this.selectedCreditFacilityFulfillmentArrangementProfile.utilizedLimitAmount)),
        primaryBSLinkItemArr: []
      }
      if (typeof (this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.loanDetails) !== 'undefined') {
        for (let i = 0; i < this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.loanDetails.length; i++) {
          let primaryBSLinkContent: primaryBSLinkItem = {
            lebel: this.getActualNameing(this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.loanDetails[i].creditFacilityType),
            accountNumber: this.accountNumberMaskFormatting(this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.loanDetails[i].displayLoanAccountNumber),
            currency: this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.loanDetails[i].currencyCode,
            amount: +((this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.loanDetails[i].foreignCurrencyLoanAmount)),
            lcAmount: +((this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.loanDetails[i].localCurrencyLoanAmount))
          }
          this.primaryBSContent.primaryBSLinkItemArr.push(primaryBSLinkContent);
        }
      }
      this.displayOutStandingLoanOnPrimaryBS = true;
      this.displayCreditLimitOnPrimaryBS = false;

      this.callsiteCatalyst('PF200OUTSTANDINGLN');
    } else if (identifier === 'CREDITLIMIT') {
      let availableLimitAmount: number = this.selectedCreditFacilityFulfillmentArrangementProfile.availableLimitAmount;
      if (availableLimitAmount < 0) {
        availableLimitAmount = 0;
      }
      this.primaryBSContent = {
        header: this.portfolioFinance350ContentData.Txt_PortfolioFinance_CreditLimit,
        tooltipContent: '',
        lebel: this.portfolioFinance350ContentData.Txt_CreditLimit_TotalLimit,
        currency: this.selectedCreditFacilityFulfillmentArrangementProfile.currencyCode,
        amount: +((availableLimitAmount)),
        primaryBSLinkItemArr: []
      }
      if (typeof (this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.collateralDetails) !== 'undefined') {
        for (let i = 0; i < this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.collateralDetails.length; i++) {
          let primaryBSLinkContent: primaryBSLinkItem = {
            lebel: this.getActualNameing(this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.collateralDetails[i].collateralType),
            accountNumber: this.accountNumberMaskFormatting(this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.collateralDetails[i].displayCollateralAccountNumber),
            currency: this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.collateralDetails[i].currencyCode,
            amount: +((this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.collateralDetails[i].loanLimitAmount)),
            mva: +((this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.collateralDetails[i].marketValueAmount)),
            cva: +((this.RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetails.collateralDetails[i].collateralValueAmount)),
          }
          this.primaryBSContent.primaryBSLinkItemArr.push(primaryBSLinkContent);
        }
      }
      this.displayOutStandingLoanOnPrimaryBS = false;
      this.displayCreditLimitOnPrimaryBS = true;

      this.callsiteCatalyst('PF200CREDITLIMIT');
    }
    this.primaryBS = true;
  }

  public closePrimaryBS(e: Event) {
    this.primaryBS = false;
  }

  public emitClickOutsideToClosePrimaryBS(e) {
    this.primaryBS = e;
  }

  public openSeconderyBS(e: Event, index: number) {
    this.SeconderyBSIndex = index;
    this.primaryBS = false;
    this.seconderyBS = true;
    if (this.displayOutStandingLoanOnPrimaryBS) {
      this.callsiteCatalyst('PF200LOANACCDETAIL');
    } else if (this.displayCreditLimitOnPrimaryBS) {
      this.callsiteCatalyst('PF200CREDITACCDETAIL');
    }
  }

  public closeSeconderyBS(e: Event) {
    this.primaryBS = true;
    this.seconderyBS = false;
  }

  public emitClickOutsideToCloseSeconderyBS(e) {
    this.seconderyBS = e;
  }

  public openLinkBS(e: Event, identifier: string) {
    if (identifier === 'DISCLAIMER') {
      this.linkBSHeight = '68.56vh';
      this.linkBSHeaderText = this.portfolioFinance200ContentData.Txt_PFDisclaimer_Title;
      this.linkBSBodyText = this.portfolioFinance200ContentData.Txt_PFDisclaimer_Text;
      this.callsiteCatalyst('PF200LINK', this.linkBSHeaderText);
      setTimeout(() => {
        this.callsiteCatalyst('PF200DISCOPENED');
      }, 100);
    } else if (identifier === 'DEFINITION') {
      this.linkBSHeight = '53.57vh';
      this.linkBSHeaderText = this.portfolioFinance200ContentData.Txt_PFDefinition_Title;
      this.linkBSBodyText = this.portfolioFinance200ContentData.Txt_PFDefinition_Text;
      this.callsiteCatalyst('PF200LINK', this.linkBSHeaderText);
      setTimeout(() => {
        this.callsiteCatalyst('PF200DEFIOPENED');
      }, 100);
    }
    this.linkBS = true;
  }

  public closeLinkBS(e: Event) {
    this.linkBS = false;
  }

  public emitClickOutsideToCloseLinkBS(e) {
    this.linkBS = e;
  }

  public displayApiFailure() {
    this.apiErroPage = true;
    this.callsiteCatalyst('PF200ERRSENARIO', this.portfolioFinance200ContentData.Link_LoadPortfolioFinance_Retry);
  }

  public displayApiFailureBS() {
    this.apiErrorBS = true;
  }

  public closeApiErrorBS(e: Event) {
    this.apiErrorBS = false;
  }

  public emitClickOutsideToCloseApiErrorBS(e) {
    this.apiErrorBS = e;
  }

  public getActualNameing(codeName: string) {
    let actualName: string = codeName;
    switch (codeName) {

      case "DTL": {
        actualName = this.portfolioFinance300ContentData.Txt_DTLDetail_Title;
        break;
      }

      case "TD": {
        actualName = this.portfolioFinance350ContentData.Txt_TDDetail_Title;
        break;
      }

      case "SBC": {
        actualName = this.portfolioFinance350ContentData.Txt_SBDetail_Title;
        break;
      }

      case "MF": {
        actualName = this.portfolioFinance350ContentData.Txt_MFDetail_Title;
        break;
      }

      case "FIS": {
        actualName = this.portfolioFinance350ContentData.Txt_FISDetail_Title;
        break;
      }

      case "OD": {
        actualName = this.portfolioFinance300ContentData.Txt_ODAccount_Title;
        break;
      }

    }
    return actualName;
  }

  public accountNumberMaskFormatting(accountNumber: string) {
    accountNumber = accountNumber.toLowerCase().replace(/x/gi, '');
    accountNumber = "**** " + accountNumber;
    return accountNumber;
  }

  public amountRoundDown(amount: number) {
    return Math.floor(amount * 100) / 100;
  }

  public upperCaseFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  }

  public openPDF(e: Event, identifier: string) {
    let URL = '';
    if (identifier === 'PRODBROCHURE') {
      URL = this.portfolioFinance200ContentData.ProdBroChure_DocURL;
    } else if (identifier === 'PFMARKETING') {
      URL = this.portfolioFinance200ContentData.PFMarketing_DocURL;
    }
    if (URL !== '') {
      this.callsiteCatalyst('PF200MARKETINGSPACELINK', this.upperCaseFirstLetter(identifier));
      const isThick = this.appStore.getGlobalConfig().getIsThick();
      if (isThick) {
        this.cordovaService.openLinkInBrowser(URL).subscribe(() => {
        });
      } else {
        window.open(URL);
      }
    }
  }

  public gotoContactRelationshipManager(e: Event) {
    if (this.appStore.getValue('isWKbinary')) {
      this.gmHelperService.wkSettingAngularToGM();
    }
    this.cordovaService.openNativeScreenWithId("HelpAndSupport", {});
    this.callsiteCatalyst('PF200MARKETINGSPACECRMBTN');
  }

  callsiteCatalyst(identifier: string, secondParam?: string) {
    let siteConst;
    let actionType: string = "";
    switch (identifier) {

      case "PF200LANDING": {
        siteConst = this.appConst.appConstants['siteCatalyst']['portfoliofinance-200-landing'];
        actionType = "ACTION";
        break;
      }

      case "PF200SINGLEMULTIRELATIONLOAD": {
        siteConst = this.appConst.appConstants['siteCatalyst']['portfoliofinance-200-single-Multiple_relationship_onload'];
        if (this.customerRelationshipList.customerRelationship.length > 1) {
          siteConst.reminder_messages = "Multiple Relationship " + siteConst.reminder_messages;
        } else {
          siteConst.reminder_messages = "Single Relationship " + siteConst.reminder_messages;
        }
        actionType = "PAGELOAD";
        break;
      }

      case "PF200LINK": {
        siteConst = JSON.parse(JSON.stringify(this.appConst.appConstants['siteCatalyst']['portfoliofinance-200-link']));
        siteConst.cta_name = secondParam;
        siteConst.page_inter = secondParam + siteConst.page_inter;
        actionType = "ACTION";
        break;
      }

      case "PF200DISCOPENED": {
        siteConst = this.appConst.appConstants['siteCatalyst']['portfoliofinance-200-link-disclaimer'];
        actionType = "PAGELOAD";
        break;
      }

      case "PF200DEFIOPENED": {
        siteConst = this.appConst.appConstants['siteCatalyst']['portfoliofinance-200-link-definitions'];
        actionType = "PAGELOAD";
        break;
      }

      case "PF200SELECTRELATION": {
        siteConst = this.appConst.appConstants['siteCatalyst']['portfoliofinance-200-select-relationship'];
        actionType = "PAGELOAD";
        break;
      }

      case "PF200OUTSTANDINGLN": {
        siteConst = this.appConst.appConstants['siteCatalyst']['portfoliofinance-200-outstandingLoan'];
        actionType = "PAGELOAD";
        break;
      }

      case "PF200LOANACCDETAIL": {
        siteConst = this.appConst.appConstants['siteCatalyst']['portfoliofinance-200-loanAccountDetail'];
        actionType = "PAGELOAD";
        break;
      }

      case "PF200CREDITLIMIT": {
        siteConst = this.appConst.appConstants['siteCatalyst']['portfoliofinance-200-creditLimit'];
        actionType = "PAGELOAD";
        break;
      }

      case "PF200CREDITACCDETAIL": {
        siteConst = this.appConst.appConstants['siteCatalyst']['portfoliofinance-200-creditAccountDetail'];
        actionType = "PAGELOAD";
        break;
      }

      case "PF200MARKETINGSPACE": {
        siteConst = this.appConst.appConstants['siteCatalyst']['portfoliofinance-200-marketing-space'];
        actionType = "PAGELOAD";
        break;
      }

      case "PF200MARKETINGSPACELINK": {
        siteConst = this.appConst.appConstants['siteCatalyst']['portfoliofinance-200-marketing-space-link'];
        siteConst.cta_name = secondParam + '|' + siteConst.cta_name;
        siteConst.page_inter = secondParam + siteConst.page_inter;
        actionType = "ACTION";
        break;
      }

      case "PF200MARKETINGSPACECRMBTN": {
        siteConst = this.appConst.appConstants['siteCatalyst']['portfoliofinance-200-marketing-space-CRM-btn'];
        siteConst.page_inter = "Contact relationship manager button" + siteConst.page_inter;
        actionType = "ACTION";
        break;
      }

      case "PF200ERRSENARIO": {
        siteConst = this.appConst.appConstants['siteCatalyst']['portfoliofinance-200-errorScenario'];
        siteConst.error_message = secondParam;
        siteConst.cust_error = siteConst.cust_error + secondParam;
        actionType = "PAGELOAD";
        break;
      }
    }
    this.analyticsEngine.setDefaultValue(siteConst);
    if (actionType === "ACTION") {
      this.analyticsEngine.triggerSiteCatalyst(AnalyticsType.ACTION, siteConst, siteConst.page_inter);
    } else if (actionType === "PAGELOAD") {
      this.analyticsEngine.triggerSiteCatalyst(AnalyticsType.PAGELOAD, siteConst);
    }
  }

}
