import { Component, Inject, Input, OnChanges, ViewChild, ElementRef, ɵCssSelectorList } from '@angular/core';
import { ILoggerService } from '@citi-gcg-167407/core-services'

@Component({
  selector: 'portfolio-piChart',
  templateUrl: './pf-piChart.component.html',
  styleUrls: ['./pf-piChart.component.scss']
})
export class portfolioPiChartComponent implements OnChanges {
  @ViewChild('canvas1') canvas1: ElementRef;
  @ViewChild('innerCircel') innerCircel: ElementRef;

  @Input() public percent: number;
  @Input() public radius: number;
  @Input() public startArcColors: string;
  @Input() public endArcColors: string;
  @Input() public arcThikness: number;
  @Input() public piChartText: string;

  public outerLeftMargin: number = 16;
  public outerTopMargin: number = 16;
  public canvasWidth: number = 162;
  public canvasHeight: number = 162;
  public innerCircelWidth: number = 120;
  public innerCircelHeight: number = 120;

  constructor(
    @Inject('ILoggerService') private oLogger: ILoggerService
  ) {
  }

  ngOnChanges() {
    this.buildPiChart();
  }

  public buildPiChart() {

    /*-------------------------------Right Left Start End Fraction Calculation------------------------*/
    let rightStartFraction = 0;
    let rightEndFraction = 0;
    let leftStartFraction = 0;
    let leftEndFraction = 0;
    if (this.percent <= 50) {
      rightStartFraction = 1.5;
      rightEndFraction = rightStartFraction + (this.percent / 50);
      leftStartFraction = 0;
      leftEndFraction = 0;
    } else if (this.percent > 50 && this.percent <= 100) {
      rightStartFraction = 1.5;
      rightEndFraction = 2.5;
      leftStartFraction = 0;
      leftEndFraction = ((this.percent - 50) / 50) * 1.5;
      if (this.percent > 50 && this.percent < 56) {
        leftEndFraction = leftEndFraction + 0.45;
      } else if (this.percent > 55 && this.percent < 61) {
        leftEndFraction = leftEndFraction + 0.38;
      } else if (this.percent > 60 && this.percent < 67) {
        leftEndFraction = leftEndFraction + 0.27;
      }
    }
    //console.log("rightStartFraction : " + rightStartFraction + "; rightEndFraction : " + rightEndFraction + "; leftStartFraction : " + leftStartFraction + "; leftEndFraction : " + leftEndFraction);
    /*-------------------------------Right Left Start End Fraction Calculation------------------------*/

    let can = this.canvas1.nativeElement;
    let ctx = can.getContext('2d');

    ctx.translate(this.outerLeftMargin, this.outerTopMargin); // just to get it away from the edge

    /*-------------------------------Canvas width& Height Calculation---------------------------------*/
    this.canvasWidth = (this.radius * 2) + (this.outerLeftMargin * 2);
    this.canvasHeight = (this.radius * 2) + (this.outerTopMargin * 2);
    //console.log('canvasWidth : ' + this.canvasWidth + '; canvasHeight : ' + this.canvasHeight);
    /*-------------------------------Canvas width& Height Calculation---------------------------------*/

    /*-------------------------------Canvas Middle Arc Color Derivation-------------------------------*/
    let middleArcColor = '#' + this.deriveMiddleColor(this.startArcColors, this.endArcColors);
    //console.log('middleArcColor : ' + middleArcColor);
    /*-------------------------------Canvas Middle Arc Color Derivation-------------------------------*/

    let darkPart = ctx.createLinearGradient(0, 0, 0, 100);
    darkPart.addColorStop(0, this.endArcColors);
    darkPart.addColorStop(1, middleArcColor);

    let lightPart = ctx.createLinearGradient(0, 0, 0, 100);
    lightPart.addColorStop(0, this.startArcColors);
    lightPart.addColorStop(1, middleArcColor);

    ctx.lineWidth = this.arcThikness;

    // First we make a clipping region for the left half
    ctx.save();
    ctx.beginPath();
    ctx.rect(-this.arcThikness, -this.arcThikness, this.radius + this.arcThikness, (this.radius * 2) + this.arcThikness * 2);
    ctx.clip();

    // Then we draw the left half
    ctx.strokeStyle = darkPart;
    ctx.beginPath();
    ctx.lineCap = "round";
    ctx.arc(this.radius, this.radius, this.radius, Math.PI * leftStartFraction, Math.PI * leftEndFraction, false);
    ctx.stroke();

    ctx.restore(); // restore clipping region to default

    // Then we make a clipping region for the right half
    ctx.save();
    ctx.beginPath();
    ctx.rect(this.radius, -this.arcThikness, this.radius + this.arcThikness, (this.radius * 2) + this.arcThikness * 2);
    ctx.clip();

    // Then we draw the right half
    ctx.strokeStyle = lightPart;
    ctx.beginPath();
    ctx.lineCap = "round";
    ctx.arc(this.radius, this.radius, this.radius, Math.PI * rightStartFraction, Math.PI * rightEndFraction, false);
    ctx.stroke();

    ctx.restore(); // restore clipping region to default

    /*-------------------------------Inner Circle width & Height Calculation--------------------------*/
    let innerCircel = this.innerCircel.nativeElement;
    this.innerCircelWidth = (this.radius * 2) - this.arcThikness;
    this.innerCircelHeight = (this.radius * 2) - this.arcThikness;
    //console.log('innerCircelWidth : ' + this.innerCircelWidth + '; innerCircelHeight : ' + this.innerCircelHeight);
    //innerCircel.setAttribute("style", "width:" + this.innerCircelWidth + "; height: " + this.innerCircelHeight + ";");
    /*-------------------------------Inner Circle width & Height Calculation--------------------------*/
  }

  public deriveMiddleColor(startColor: string, endColor: string) {
    if (startColor !== null) {
      startColor = startColor.replace("#", "");
    } else {
      startColor = 'a89f69';
    }
    if (endColor !== null) {
      endColor = endColor.replace("#", "");
    } else {
      endColor = '6b5019';
    }
    let ratio = 0.5;
    let hex = function (x) {
      x = x.toString(16);
      return (x.length == 1) ? '0' + x : x;
    };

    let r = Math.ceil(parseInt(startColor.substring(0, 2), 16) * ratio + parseInt(endColor.substring(0, 2), 16) * (1 - ratio));
    let g = Math.ceil(parseInt(startColor.substring(2, 4), 16) * ratio + parseInt(endColor.substring(2, 4), 16) * (1 - ratio));
    let b = Math.ceil(parseInt(startColor.substring(4, 6), 16) * ratio + parseInt(endColor.substring(4, 6), 16) * (1 - ratio));

    let middle = hex(r) + hex(g) + hex(b);

    return middle;
  }
}
