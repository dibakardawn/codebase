import { Component, Inject, Input, OnChanges } from '@angular/core';
import { ILoggerService } from '@citi-gcg-167407/core-services'

@Component({
  selector: 'pf-spinner',
  templateUrl: './pf-spinner.component.html',
  styleUrls: ['./pf-spinner.component.scss']
})
export class pfSpinnerComponent implements OnChanges {
  @Input() public displaySpinner = false;
  @Input() public blockerHeight = 0;

  public spinnerTop = 0;

  constructor(
    @Inject('ILoggerService') private oLogger: ILoggerService
  ) { }

  ngOnChanges() {
    if (this.blockerHeight !== 0) {
      this.spinnerTop = Math.round(this.blockerHeight / 2) - 16;
    }
  }
}
