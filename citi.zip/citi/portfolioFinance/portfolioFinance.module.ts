import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CordovaHttpModule } from '@citi-gcg-167407/core-services';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CitiCommonModule } from '@citi-gcg-167407/common';
import { ButtonModule, BottomSheetModule } from '@citi-gcg-167407/core-uiux';

import { portfolioFinanceRoutingModule } from './portfolioFinance-routing.module';
import { portfolioFinanceComponent } from './portfolioFinance.component';

import { portfolioFinanceAPIService } from './services/portfolioFinance-API.Service';
import { portfolioFinanceCommonService } from './services/portfolioFinance-Common.service';

import { pfSpinnerComponent } from './portfolioFinanceCommon/pf-spinner/pf-spinner.component';
import { portfolioPiChartComponent } from './portfolioFinanceCommon/pf-piChart/portfolio-piChart.component';

import { portfolioFinance200Component } from './portfolioFinance_200/pages/portfolioFinance_200.component';
import { portfolioFinance800Component } from './portfolioFinance_800/pages/portfolioFinance_800.component';

import { amount2DP } from './pipe/amount2DP.pipe';

@NgModule({
  imports: [
    CommonModule,
    CordovaHttpModule,
    FormsModule,
    CitiCommonModule,
    portfolioFinanceRoutingModule,
    ButtonModule.forRoot(),
    BottomSheetModule.forRoot(),
    ReactiveFormsModule
  ],
  declarations: [
    portfolioFinanceComponent,
    portfolioFinance200Component,
    portfolioFinance800Component,
    pfSpinnerComponent,
    portfolioPiChartComponent,
    amount2DP
  ],
  exports: [],
  providers: [
    portfolioFinanceAPIService,
    portfolioFinanceCommonService
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class portfolioFinanceModule { }
