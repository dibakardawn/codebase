import { Injectable, Inject } from '@angular/core';
import { ILoggerService, IPrettyLogger, AppStore } from '@citi-gcg-167407/core-services';
import { AppController } from '@citi-gcg-167407/common';
import { throwError as observableThrowError, Observable, of } from 'rxjs';
import { map, tap, catchError } from 'rxjs/operators';

import {
  customerRelationship,
  CustomerRelationshipListResponse,
  creditFacilityDetails,
  RetrieveCreditFacilityFulfillmentArrangementSummaryResponse,
  collateralDetails,
  loanDetails,
  RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetailsResponse
} from '../models/portfolioFinance';

@Injectable()
export class portfolioFinanceAPIService {
  private prettyLogger: IPrettyLogger;

  constructor(
    private appStore: AppStore,
    private appController: AppController,
    @Inject('ILoggerService') logger: ILoggerService
  ) {
    this.prettyLogger = logger.prettyLogger('portfolioFinance API Service');
  }

  public checkSuccessStatus(response): boolean {
    return response && response.rs && response.rs.success && response.rs.rsData;
  }

  /*---------------------------Portfolio Finance API------------------------------------------------- */
  public getCustomerRelationshipList(): Observable<CustomerRelationshipListResponse> {
    const TAG = 'apiCustomerRelationshipList() ';
    // API GET CALL: To get any existing knowledge and experience
    return this.appController.post('portfolioFinance', 'getRelationshipList', {}, {})
      .pipe(
        map((response) => {
          if (this.checkSuccessStatus(response)) {
            return response.rs.rsData;
          }
          return null;
        }),
        catchError((error: any) => {
          this.prettyLogger.error(TAG, 'Server Error');
          return of(false);
        })
      );
  }

  public getRetrieveCreditFacilityFulfillmentArrangementSummaryResponse(): Observable<RetrieveCreditFacilityFulfillmentArrangementSummaryResponse>{
    const TAG = 'RetrieveCreditFacilityFulfillmentArrangementSummaryResponse() ';
    return this.appController.post('portfolioFinance', 'pfRelationshipSummary', {}, {})
      .pipe(
        map((response) => {
          if (this.checkSuccessStatus(response)) {
            return response.rs.rsData;
          } else {
            return false;
          }
        }),
        catchError((error: any) => {
          this.prettyLogger.error(TAG, 'Server Error');
          return of(false);
        })
      );
  }

  public getRetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetailsResponse(relationshipId: string): Observable<RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetailsResponse> {
    const TAG = 'getRetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetailsResponse() ';
    const reqParam: any = {};
    reqParam.uriParam = [relationshipId];
    return this.appController.post('portfolioFinance', 'collateralNLoan', {}, reqParam)
      .pipe(
        map((response) => {
          if (this.checkSuccessStatus(response)) {
            return response.rs.rsData;
          } else {
            return false;
          }
        }),
        catchError((error: any) => {
          this.prettyLogger.error(TAG, 'Server Error');
          return of(false);
        })
      );
  }
  /*---------------------------Portfolio Finance API------------------------------------------------- */
}
