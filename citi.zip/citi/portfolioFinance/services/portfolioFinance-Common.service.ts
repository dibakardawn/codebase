import { Injectable } from '@angular/core';
import { AppStore } from '@citi-gcg-167407/core-services';

@Injectable()
export class portfolioFinanceCommonService {
  public isNative = false;
  constructor(
    //private appStore: AppStore
  ) { }

  private _relationshipId: string = '';

  /*--------------------------------Portfolio Finance------------------- */
  public set relationshipId(relationshipId: string) {
    this._relationshipId = relationshipId;
  }

  public get relationshipId() {
    return this._relationshipId;
  }
  /*--------------------------------Portfolio Finance------------------- */
}
