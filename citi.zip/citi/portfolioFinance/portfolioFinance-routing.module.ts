import { Routes, RouterModule } from '@angular/router';
import { MRCPostLoginResolver, ContentResolver } from '@citi-gcg-167407/common';
import { NgModule } from '@angular/core';
import { portfolioFinanceComponent } from './portfolioFinance.component';

import { portfolioFinance200Component } from './portfolioFinance_200/pages/portfolioFinance_200.component';
import { portfolioFinance800Component } from './portfolioFinance_800/pages/portfolioFinance_800.component';

const ROUTES: Routes = [{
  path: '',
  component: portfolioFinanceComponent,
  data: {
    content: [
      { moduleName: 'portfolioFinance' }
    ]
  },
  resolve: {
    prelogin: MRCPostLoginResolver,
    content: ContentResolver
  },
  children: [
    {
      path: 'portfolioFinance_200',
      component: portfolioFinance200Component
    },
    {
      path: 'portfolioFinance_800',
      component: portfolioFinance800Component
    }
  ]
}];

@NgModule({
  imports: [
    RouterModule.forChild(ROUTES)
  ],
  exports: [
    RouterModule
  ],
  providers: [
  ]
})

export class portfolioFinanceRoutingModule { }
