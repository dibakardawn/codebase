import { Component, OnInit, HostBinding, Inject, AfterViewInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ContentService, ILoggerService } from '@citi-gcg-167407/core-services';
import { routeAnimation, BaseComponent, AnimationService, SessionExtService, CitiWindow, WINDOW } from '@citi-gcg-167407/common';

@Component({
  selector: 'portfolioFinance_800',
  templateUrl: './portfolioFinance_800.component.html',
  styleUrls: ['./portfolioFinance_800.component.scss'],
  animations: [routeAnimation]
})
export class portfolioFinance800Component extends BaseComponent implements OnInit {
  @HostBinding('@routing') public routing;
  public animationServiceEventsSubscription: any;
  public insuranceDetailsExpand: boolean = false;
  public displaySpinner: boolean = false;
  constructor(
    private router: Router,
    private animationService: AnimationService,
    private contentService: ContentService,
    sessionExtService: SessionExtService,
    @Inject(WINDOW) private win: CitiWindow,
    @Inject('ILoggerService') oLogger: ILoggerService
  ) {
    super(oLogger, sessionExtService);
  }

  ngOnInit() {
    this.routing = this.animationService.animationDirection();
    this.animationServiceEventsSubscription = this.animationService.emitCurrentDirection.subscribe((direction: any) => {
      this.routing = direction;
    });
    this.displaySpinner = true;
    // Logic BAU
    this.gotoPortfolioFinance800()
  }


  public gotoPortfolioFinance800() {
    let queryParams = {};
    this.animationService.routingService('upward', this.router.url, 'portfolioFinance/portfolioFinance_200', { queryParams });
  }
}
