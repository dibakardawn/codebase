export class portfolioFinanceConstants {
  public static defalutRelationshipTypes = ['IND', 'SOLE_OWNER'];
  public static otherRelationshipTypes = ['JOR'];
}
