export interface customerRelationship {
  relationshipId: string,
  displayRelationshipNumber: string,
  relationshipTitle: string,
  relationshipType: string
}

export interface CustomerRelationshipListResponse {
  customerRelationship: customerRelationship[]
}

export interface creditFacilityDetails {
  portfolioPowerFlag: boolean,
  displayRelationshipNumber: string,
  relationshipId: string,
  availableLimitAmount: number,
  utilizedLimitAmount: number,
  utilizationPercent: number,
  availableAmount: number,
  currencyCode: string
}

export interface RetrieveCreditFacilityFulfillmentArrangementSummaryResponse {
  creditFacilityDetails: creditFacilityDetails[]
}

export interface collateralDetails {
  displayCollateralAccountNumber: string,
  collateralType: string,
  marketValueAmount: number,
  collateralValueAmount: number,
  loanLimitAmount: number,
  currencyCode: string
}

export interface loanDetails {
  displayLoanAccountNumber: string,
  creditFacilityType: string,
  currencyCode: string,
  foreignCurrencyLoanAmount: number,
  localCurrencyLoanAmount: number
}

export interface RetrieveCreditFacilityFulfillmentArrangementCollateralAndOutstandingLoanDetailsResponse {
  collateralDetails: collateralDetails[],
  loanDetails: loanDetails[]
}

export interface piChartObj {
  percent: number,
  radius: number,
  startArcColors: string,
  endArcColors: string,
  arcThikness: number,
  piChartText: string
}

export interface primaryBSLinkItem {
  lebel?: string,
  accountNumber?: string,
  currency?: string,
  amount?: number,
  lcAmount?: number,
  mva?: number,
  cva?: number
}

export interface primaryBScontentMapper {
  header?: string,
  tooltipContent?: string,
  lebel?: string,
  currency?: string,
  amount?: number,
  primaryBSLinkItemArr?: primaryBSLinkItem[]
}
