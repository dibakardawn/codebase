import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'amount2DP'
})

export class amount2DP implements PipeTransform {
  transform(amount: number, fixed: number): number {
    let  re =  new  RegExp('^-?\\d+(?:\.\\d{0,'  + (fixed ||  -1) +  '})?');
    return +(String(amount).match(re)[0]);
  }
}
