import { Component } from '@angular/core';

@Component({
  selector: 'portfolioFinance',
  template: '<router-outlet></router-outlet>'
})
export class portfolioFinanceComponent { }
