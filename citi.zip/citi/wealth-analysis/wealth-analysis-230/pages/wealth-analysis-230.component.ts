import { Component, OnChanges, HostBinding, Inject, Input, Output, EventEmitter } from '@angular/core';
import { ContentService, ILoggerService } from '@citi-gcg-167407/core-services';
import { routeAnimation, AnimationService, SessionExtService, CitiWindow, WINDOW } from '@citi-gcg-167407/common';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'wealth-analysis-230',
  templateUrl: './wealth-analysis-230.component.html',
  styleUrls: ['./wealth-analysis-230.component.scss'],
  animations: [routeAnimation]
})
export class WealthAnalysis230Component implements OnChanges {
  @HostBinding('@routing') public routing;
  @Input() public identifire: string;
  @Output() wealthAnalysis230BSCloseEmmiter: EventEmitter<boolean> = new EventEmitter();
  public animationServiceEventsSubscription: any;
  public assetBase: string;
  public wealthAnalysisContents: any;
  public commonBSHeader: string;
  public commonBSDesc: string;
  public commonBSOk: string;

  constructor(
    private animationService: AnimationService,
    private contentService: ContentService,
    private appService: AppService,
    sessionExtService: SessionExtService,
    @Inject(WINDOW) private win: CitiWindow,
    @Inject('ILoggerService') oLogger: ILoggerService
  ) {

  }

  ngOnChanges() {
    this.routing = this.animationService.animationDirection();
    this.animationServiceEventsSubscription = this.animationService.emitCurrentDirection.subscribe((direction: any) => {
      this.routing = direction;
    });
    this.assetBase = this.appService.getAsset();
    this.wealthAnalysisContents = this.contentService.getContentFromStore('wealthanalysis', 'wealthanalysis');
    this.openCommonBS(this.identifire);
  }

  public openCommonBS(identifire: string) {
    switch (identifire) {

      case "READMORE": {
        this.commonBSHeader = this.wealthAnalysisContents.wealthanalysis_230.Hdr_Glossary_Header;
        this.commonBSDesc = this.wealthAnalysisContents.wealthanalysis_230.Txt_Glossary_Disclaimer;
        break;
      }

      case "CURRENTTOTALASSETS": {
        this.commonBSHeader = this.wealthAnalysisContents.wealthanalysis_230.Hdr_CurrentAssets_Header;
        this.commonBSDesc = this.wealthAnalysisContents.wealthanalysis_230.Txt_CurrentAssets_Text;
        break;
      }

      case "TOTALASSETTRENDING": {
        this.commonBSHeader = this.wealthAnalysisContents.wealthanalysis_230.Hdr_TotalTrending_Header;
        this.commonBSDesc = this.wealthAnalysisContents.wealthanalysis_230.Txt_TotalTrending_Text;
        break;
      }

      case "TOTALINVESTMENTASSET": {
        this.commonBSHeader = this.wealthAnalysisContents.wealthanalysis_230.Hdr_TotaInvAssets_Header;
        this.commonBSDesc = this.wealthAnalysisContents.wealthanalysis_230.Txt_TotalInvAssets_Text;
        break;
      }

      case "HOWDOESITWORK": {
        this.commonBSHeader = this.wealthAnalysisContents.wealthanalysis_230.Hdr_InvHow_Header;
        this.commonBSDesc = this.wealthAnalysisContents.wealthanalysis_230.Txt_InvHow_Text;
        break;
      }

      case "TOTALDEPOSITS": {
        this.commonBSHeader = this.wealthAnalysisContents.wealthanalysis_230.Hdr_TotalDeposits_Header;
        this.commonBSDesc = this.wealthAnalysisContents.wealthanalysis_230.Txt_TotalDeposits_Text;
        break;
      }

      case "HISTORICALBALANCETRENDING": {
        this.commonBSHeader = this.wealthAnalysisContents.wealthanalysis_230.Hdr_DepositsTrending_Header;
        this.commonBSDesc = this.wealthAnalysisContents.wealthanalysis_230.Txt_DepositsTrending_Text;
        break;
      }

      case "GAINLOSSREALIZEDPOSITIONS": {
        this.commonBSHeader = this.wealthAnalysisContents.wealthanalysis_230.Hdr_GLRealized_Header;
        this.commonBSDesc = this.wealthAnalysisContents.wealthanalysis_230.Txt_GLRealized_Text;
        break;
      }

      case "GAINLOSSCURRENTINVESTMENTHOLDINGS": {
        this.commonBSHeader = this.wealthAnalysisContents.wealthanalysis_230.Hdr_GLHoldings_Header;
        this.commonBSDesc = this.wealthAnalysisContents.wealthanalysis_230.Txt_GLHoldings_Text;
        break;
      }

      case "TOTALGAINLOSS": {
        this.commonBSHeader = this.wealthAnalysisContents.wealthanalysis_230.Hdr_TotalGL_Header;
        this.commonBSDesc = this.wealthAnalysisContents.wealthanalysis_230.Txt_TotalGL_Text;
        break;
      }

    }
    this.commonBSOk = this.wealthAnalysisContents.wealthanalysis_230.Btn_Glossary_Ok;
  }

  public closeCommonBS(e: Event) {
    this.wealthAnalysis230BSCloseEmmiter.emit(true);
  }

}
