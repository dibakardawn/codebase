import { Routes, RouterModule } from '@angular/router';
import { MRCPostLoginResolver, ContentResolver } from '@citi-gcg-167407/common';
import { NgModule } from '@angular/core';
import { WealthAnalysisComponent } from './wealt-analysis.component';

import { WealthAnalysis200Component } from './wealth-analysis-200/pages/wealth-analysis-200.component';
import { WealthAnalysisMainComponent } from './wealth-analysis-main/wealth-analysis-main.component';

const ROUTES: Routes = [{
  path: '',
  component: WealthAnalysisComponent,
  data: {
    content: [
      { moduleName: 'wealthanalysis' }
    ]
  },
  resolve: {
    content: ContentResolver
  },
  children: [
    {
      path: 'wealth-analysis-main',
      component: WealthAnalysisMainComponent
    }
  ]
}];

@NgModule({
  imports: [
    RouterModule.forChild(ROUTES)
  ],
  exports: [
    RouterModule
  ],
  providers: [
  ]
})

export class WealthAnalysisRoutingModule { }
