import { Component, OnInit, HostBinding } from '@angular/core';
import { routeAnimation, AnimationService, } from '@citi-gcg-167407/common';
import { Router } from '@angular/router';
import { AppService } from 'src/app/app.service';
import { ContentService } from '@citi-gcg-167407/core-services';
@Component({
  selector: 'wealth-analysis-main',
  templateUrl: './wealth-analysis-main.component.html',
  styleUrls: ['./wealth-analysis-main.component.scss'],
  animations: [routeAnimation]
})
export class WealthAnalysisMainComponent implements OnInit {
  @HostBinding('@routing') public routing;
  public assetBase: string;
  public selectedTab: string = "OVERVIEW";
  public content200: any = {};
  public content300: any = {};
  public content400: any = {};
  public headerText: string;
  public tab1Title: string;
  public tab2Title: string;
  public tab3Title: string;
  public disclaimerText: string;
  public learnMoreText: string;
  public wealthAnalysis_230BS: boolean = false;
  public wealthAnalysis_230BSidentifire: string = '';

  constructor(
    private router: Router,
    private appService: AppService,
    private contentService: ContentService
  ) { }

  ngOnInit() {
    this.assetBase = this.appService.getAsset();
    const contents: any = this.contentService.getContentFromStore('wealthanalysis', 'wealthanalysis');
    this.content200 = contents.wealthanalysis_200;
    this.content300 = contents.wealthanalysis_300;
    this.content400 = contents.wealthanalysis_400;
    this.headerText = this.content200.Hdr_WealthAnalysis_Header;
    this.tab1Title = this.content200.Link_WealthAnalysis_Overview;
    this.tab2Title = this.content200.Link_WealthAnalysis_Investment;
    this.tab3Title = this.content200.Link_WealthAnalysis_Deposits;
    this.disclaimerText = this.content200.Txt_WealthAnalysis_Disclaimer;
    this.learnMoreText = this.content200.Link_WealthAnalysis_LearnMore;
  }

  goToTabMenu(value: string) {
    this.selectedTab = value;
    switch (this.selectedTab) {

      case 'OVERVIEW':
        this.headerText = this.content200.Hdr_WealthAnalysis_Header;
        this.tab1Title = this.content200.Link_WealthAnalysis_Overview;
        this.tab2Title = this.content200.Link_WealthAnalysis_Investment;
        this.tab3Title = this.content200.Link_WealthAnalysis_Deposits;
        this.disclaimerText = this.content200.Txt_WealthAnalysis_Disclaimer;
        this.learnMoreText = this.content200.Link_WealthAnalysis_LearnMore;
        break;

      case 'INVESTMENT':
        this.headerText = this.content300.Hdr_WealthAnalysis_Header;
        this.tab1Title = this.content300.Link_WealthAnalysis_Overview;
        this.tab2Title = this.content300.Link_WealthAnalysis_Investment;
        this.tab3Title = this.content300.Link_WealthAnalysis_Deposits;
        this.disclaimerText = this.content300.Txt_WealthAnalysis_Disclaimer;
        this.learnMoreText = this.content200.Link_WealthAnalysis_LearnMore;
        break;

      case 'DEPOSIT':
        this.headerText = this.content400.Hdr_WealthAnalysis_Header;
        this.tab1Title = this.content400.Link_WealthAnalysis_Overview;
        this.tab2Title = this.content400.Link_WealthAnalysis_Investment;
        this.tab3Title = this.content400.Link_WealthAnalysis_Deposits;
        this.disclaimerText = this.content400.Txt_WealthAnalysis_Disclaimer;
        this.learnMoreText = this.content200.Link_WealthAnalysis_LearnMore;
        break;

      default:
        break;
    }
  }

  public learnMoreClicked(e: Event): void {
    this.openWealthAnalysis_230BS('READMORE');
  }

  //--------------------------------------- 230 -----------------------------------
  public openWealthAnalysis_230BS(identifire: string) {
    this.wealthAnalysis_230BS = true;
    this.wealthAnalysis_230BSidentifire = identifire;
  }

  public closeWealthAnalysis_230BS(e: Event) {
    this.wealthAnalysis_230BS = false;
  }

  public emitClickOutsideToCloseWealthAnalysis_230BS(e) {
    this.wealthAnalysis_230BS = e;
  }
  //--------------------------------------- 230 -----------------------------------
}
