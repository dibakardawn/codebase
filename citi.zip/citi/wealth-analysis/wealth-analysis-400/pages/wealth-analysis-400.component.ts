import { Component, OnInit, Inject, Input } from '@angular/core';
import { ContentService, ILoggerService } from '@citi-gcg-167407/core-services';
import { BaseComponent, SessionExtService, AppUtils } from '@citi-gcg-167407/common';
import { AppService } from 'src/app/app.service';

import { CapsuleMenuItem, DepositProductsAPIResponse, depositsSummaryItem } from '../../models/wealth-analysis.model';
import { barGraphItem } from 'src/apps/retail-common/model/retail-bargraph.model';
import { currencyItem } from 'src/apps/retail-common/model/retail-currency-breakdown.model';

import { WealthAnalysisAPIService } from '../../services/wealth-analysis-api.service';

@Component({
  selector: 'wealth-analysis-400',
  templateUrl: './wealth-analysis-400.component.html',
  styleUrls: ['./wealth-analysis-400.component.scss']
})
export class WealthAnalysis400Component extends BaseComponent implements OnInit {
  public assetBase: string;
  public wealthAnalysisContents: any;
  public contents400: any = {};
  public capsuleMenuList: CapsuleMenuItem[];

  public displayHistoricalBalanceTreading: boolean = false;
  public depositProductsResponse: DepositProductsAPIResponse;
  public switchdisable: boolean = false;
  public localToggleSwitchState: boolean = false;
  public switchedToSGD: boolean = false;
  public processDate: string = '';
  public totalAmount: number;
  public barGraphItems: barGraphItem[];
  public currencyItems: currencyItem[] = [];

  public wealthAnalysis_230BS: boolean = false;
  public wealthAnalysis_230BSidentifire: string = '';
  public displaySpinner: boolean = false;

  constructor(
    private appService: AppService,
    private appUtils: AppUtils,
    private contentService: ContentService,
    private waApiService: WealthAnalysisAPIService,
    sessionExtService: SessionExtService,
    @Inject('ILoggerService') oLogger: ILoggerService
  ) {
    super(oLogger, sessionExtService);
  }

  ngOnInit() {
    this.assetBase = this.appService.getAsset();
    this.wealthAnalysisContents = this.contentService.getContentFromStore('wealthanalysis', 'wealthanalysis');
    this.contents400 = this.wealthAnalysisContents.wealthanalysis_400;
    this.populateCapsuleMenu();

    if (this.displayHistoricalBalanceTreading) {
      this.getDepositProductsFromAPI();
    }
  }

  private populateCapsuleMenu(): void {
    this.capsuleMenuList = this.wealthAnalysisContents.wealthAnalysis_menuButtons['DEPOSITS'];
    if (this.capsuleMenuList) {
      this.capsuleMenuList.forEach(item => {
        item.title_text = this.contents400[item.title_labelId];
      });
    }
  }

  public infoIconClick(e: Event) {
    this.openWealthAnalysis_230BS('HISTORICALBALANCETRENDING');
  }

  private getDepositProductsFromAPI() {
    this.waApiService.getDepositProducts().subscribe((depositProductsResponse) => {
      if (depositProductsResponse) {
        this.depositProductsResponse = depositProductsResponse;
        this.processDate = this.depositProductsResponse.depositsSummary[0].processDate;
        this.totalAmount = this.depositProductsResponse.depositsSummary[0].totalAmount;
        this.initBarGraphData();
        this.initCurrencyBreakDownData();
      } else {
        //raise common error bottomsheet xxxx
      }
      this.displaySpinner = false;
    }, (error) => {
      this.displaySpinner = false;
      //raise common error bottomsheet xxxx
    });
  }

  private initBarGraphData() { //should be populated from API, but the response yet not finalized
    let barGraphItem1: barGraphItem = {
      currency: "SGD",
      amount: 60000,
      tooltipText: this.contents400.Txt_DepGraph_AsOf + this.processDate,
      percentage: 75,
      btnText: this.contents400.Btn_DepGraph_Jun
    }
    let barGraphItem2: barGraphItem = {
      currency: "SGD",
      amount: 60000,
      tooltipText: this.contents400.Txt_DepGraph_AsOf + this.processDate,
      percentage: 60,
      btnText: this.contents400.Btn_DepGraph_Jul
    }
    let barGraphItem3: barGraphItem = {
      currency: "SGD",
      amount: 60000,
      tooltipText: this.contents400.Txt_DepGraph_AsOf + this.processDate,
      percentage: 65,
      btnText: this.contents400.Btn_DepGraph_Aug
    }
    let barGraphItem4: barGraphItem = {
      currency: "SGD",
      amount: 60000,
      tooltipText: this.contents400.Txt_DepGraph_AsOf + this.processDate,
      percentage: 80,
      btnText: this.contents400.Btn_DepGraph_Sep
    }
    let barGraphItem5: barGraphItem = {
      currency: "SGD",
      amount: 60000,
      tooltipText: this.contents400.Txt_DepGraph_AsOf + this.processDate,
      percentage: 100,
      btnText: this.contents400.Btn_DepGraph_Oct
    }
    let barGraphItem6: barGraphItem = {
      currency: "SGD",
      amount: 60000,
      tooltipText: this.contents400.Txt_DepGraph_AsOf + this.processDate,
      percentage: 92,
      btnText: this.contents400.Btn_DepGraph_Nov
    }
    let barGraphItem7: barGraphItem = {
      currency: "SGD",
      amount: 60000,
      tooltipText: this.contents400.Txt_DepGraph_AsOf + this.processDate,
      percentage: 88,
      btnText: this.contents400.Btn_DepGraph_Dec
    }
    let barGraphItem8: barGraphItem = {
      currency: "SGD",
      amount: 60000,
      tooltipText: this.contents400.Txt_DepGraph_AsOf + this.processDate,
      percentage: 90,
      btnText: this.contents400.Btn_DepGraph_Jan
    }
    this.barGraphItems = [barGraphItem1, barGraphItem2, barGraphItem3, barGraphItem4, barGraphItem5, barGraphItem6, barGraphItem7, barGraphItem8];
  }

  public onToggleChange(e: TouchEvent) {
    if (this.switchedToSGD) {
      this.switchedToSGD = false;
    } else {
      this.switchedToSGD = true
    }
    this.initCurrencyBreakDownData();
  }

  private initCurrencyBreakDownData() {
    this.currencyItems = [];
    let depositsSummary: depositsSummaryItem = this.depositProductsResponse.depositsSummary[0];
    for (let i = 0; i < depositsSummary.productCurrencyBreakdownList.length; i++) {
      let currencyItem: currencyItem = {
        currency: depositsSummary.productCurrencyBreakdownList[i].productCurrencyCode,
        amount: (this.switchedToSGD === true) ? depositsSummary.productCurrencyBreakdownList[i].localCurrencyAmount : depositsSummary.productCurrencyBreakdownList[i].productCurrencyAmount,
        percentage: +(((depositsSummary.productCurrencyBreakdownList[i].localCurrencyAmount * 100) / this.totalAmount).toFixed(2))
      }
      this.currencyItems.push(currencyItem);
    }
    //console.log("currencyItems : ", this.currencyItems);
  }

  //--------------------------------------- 230 -----------------------------------
  public openWealthAnalysis_230BS(identifire: string) {
    this.wealthAnalysis_230BS = true;
    this.wealthAnalysis_230BSidentifire = identifire;
  }

  public closeWealthAnalysis_230BS(e: Event) {
    this.wealthAnalysis_230BS = false;

  }

  public emitClickOutsideToCloseWealthAnalysis_230BS(e) {
    this.wealthAnalysis_230BS = e;
  }
  //--------------------------------------- 230 -----------------------------------

}
