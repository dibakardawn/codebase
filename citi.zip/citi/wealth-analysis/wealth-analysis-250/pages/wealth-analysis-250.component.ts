import { Component, OnInit, HostBinding, Inject, AfterViewInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ContentService, ILoggerService, AppStore } from '@citi-gcg-167407/core-services';
import { routeAnimation, BaseComponent, AnimationService, SessionExtService, CitiWindow, WINDOW, CustomerProfile } from '@citi-gcg-167407/common';
import { AppService } from 'src/app/app.service';

import { accordian } from 'src/apps/retail-common/model/retail-accordian.model';

import { WealthAnalysisCommonService } from '../../services/wealth-analysis-common.service';

@Component({
  selector: 'wealth-analysis-250',
  templateUrl: './wealth-analysis-250.component.html',
  styleUrls: ['./wealth-analysis-250.component.scss'],
  animations: [routeAnimation]
})
export class WealthAnalysis250Component extends BaseComponent implements OnInit {
  @HostBinding('@routing') public routing;
  public animationServiceEventsSubscription: any;
  public assetBase: string;
  public wealthAnalysisContents: any;
  public gainLossInseptionFlag: boolean = false;
  public gainLossDataIdentifire: number;
  public accordianData250: accordian;
  public accordianDataInterval: any;

  constructor(
    private animationService: AnimationService,
    private contentService: ContentService,
    private wealthAnalysisCommonService: WealthAnalysisCommonService,
    private appService: AppService,
    sessionExtService: SessionExtService,
    @Inject(WINDOW) private win: CitiWindow,
    @Inject('ILoggerService') oLogger: ILoggerService
  ) {
    super(oLogger, sessionExtService);
  }

  ngOnInit() {
    this.routing = this.animationService.animationDirection();
    this.animationServiceEventsSubscription = this.animationService.emitCurrentDirection.subscribe((direction: any) => {
      this.routing = direction;
    });
    this.assetBase = this.appService.getAsset();
    this.wealthAnalysisContents = this.contentService.getContentFromStore('wealthanalysis', 'wealthanalysis');
  }

  ngAfterViewInit() {
    try {
      this.accordianDataInterval = setInterval(() => {
        if (this.wealthAnalysisCommonService.gainLoss250DataService) {
          this.accordianData250 = this.wealthAnalysisCommonService.gainLoss250DataService;
          clearInterval(this.accordianDataInterval);
        }
      }, 100);
    } catch (e) {
      //console.log("Error @ngAfterViewInit");
    }
  }

  public onClickWA250Button(e: TouchEvent, i: string) {
    if (i === 'L12M') {
      this.gainLossInseptionFlag = false;
    } else if (i === 'SI') {
      this.gainLossInseptionFlag = true;
    }
    this.initAccordianData();
  }

  public initAccordianData() {
    this.accordianData250.header = '';
    this.accordianData250.displayChevron = false;
    for (let i = 0; i < this.accordianData250.accordianItems.length; i++) {
      if (i === this.gainLossDataIdentifire) {
        if (!this.gainLossInseptionFlag) { // for 12 Months
          if (this.accordianData250.accordianItems[i].timePeriod === "L12M") {
            this.accordianData250.accordianItems[i].display = true;
          } else {
            this.accordianData250.accordianItems[i].display = false;
          }
        }
        if (this.gainLossInseptionFlag) { // for Inseption
          if (this.accordianData250.accordianItems[i].timePeriod === "SI") {
            this.accordianData250.accordianItems[i].display = true;
          } else {
            this.accordianData250.accordianItems[i].display = false;
          }
        }
        this.accordianData250.accordianItems[i].expand = true;
      } else {
        this.accordianData250.accordianItems[i].display = false;
      }
    }
  }

  public retailAccordianInfoBtnClick(e: string) {
    //console.log(e);
  }

  ngOnDestroy() {
    if (this.accordianDataInterval) {
      clearInterval(this.accordianDataInterval);
    }
  }

}
