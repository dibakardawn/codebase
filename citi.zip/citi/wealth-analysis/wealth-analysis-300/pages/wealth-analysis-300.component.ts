import { Component, OnInit, Inject } from '@angular/core';
import { ContentService, ILoggerService } from '@citi-gcg-167407/core-services';
import { BaseComponent, SessionExtService, CustomerProfile } from '@citi-gcg-167407/common';
import { AppService } from 'src/app/app.service';
import { CapsuleMenuItem } from '../../models/wealth-analysis.model';

@Component({
  selector: 'wealth-analysis-300',
  templateUrl: './wealth-analysis-300.component.html',
  styleUrls: ['./wealth-analysis-300.component.scss']
})
export class WealthAnalysis300Component extends BaseComponent implements OnInit {

  public assetBase: string;
  public wealthAnalysisContents: any;
  public contents300: any = {};
  public capsuleMenuList: CapsuleMenuItem[];
  constructor(
    private contentService: ContentService,
    private appService: AppService,
    sessionExtService: SessionExtService,
    @Inject('ILoggerService') oLogger: ILoggerService
  ) {
    super(oLogger, sessionExtService);
  }

  ngOnInit() {
    this.assetBase = this.appService.getAsset();
    this.wealthAnalysisContents = this.contentService.getContentFromStore('wealthanalysis', 'wealthanalysis');
    this.contents300 = this.wealthAnalysisContents.wealthanalysis_300;
    this.populateCapsuleMenu();
  }

  private populateCapsuleMenu(): void {
    this.capsuleMenuList = this.wealthAnalysisContents.wealthAnalysis_menuButtons['INVESTMENT'];
    if (this.capsuleMenuList) {
      this.capsuleMenuList.forEach(item => {
        item.title_text = this.contents300[item.title_labelId];
      });
    }
  }
}
