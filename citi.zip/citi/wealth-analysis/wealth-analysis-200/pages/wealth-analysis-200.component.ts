import { Component, OnInit, Inject } from '@angular/core';
import { ContentService, ILoggerService } from '@citi-gcg-167407/core-services';
import { BaseComponent, SessionExtService, AppUtils } from '@citi-gcg-167407/common';
import { AppService } from 'src/app/app.service';
import { forkJoin } from 'rxjs';

import { CapsuleMenuItem, TotalAssetDetails, TotalAssetsTrendingResponse, TotalInvestmentGainLossAPIResponse, MoneyWeightedReturnsAPIResponse, moneyWeightedReturnsItem } from '../../models/wealth-analysis.model';
import { RetailAmount } from 'src/apps/retail-common/model/retail-amount-container.model';
import { accordian, accordianItem, accordianChildItem, accordianChildItemBreak } from 'src/apps/retail-common/model/retail-accordian.model';

import { WealthAnalysisCommonService } from '../../services/wealth-analysis-common.service';
import { WealthAnalysisAPIService } from '../../services/wealth-analysis-api.service';
import { RetailLineChartDataModel, RetailLineChartTooltipData } from 'src/apps/dvp-mutual-fund-portfolio-intro/model/retail-line-chart.model';
import * as _ from 'lodash';

@Component({
  selector: 'wealth-analysis-200',
  templateUrl: './wealth-analysis-200.component.html',
  styleUrls: ['./wealth-analysis-200.component.scss']
})
export class WealthAnalysis200Component extends BaseComponent implements OnInit {
  public assetBase: string;
  public wealthAnalysisContents: any;
  public contents200: any = {};
  public contents250: any = {};
  public headerText: string = "";
  public tabMenuIdentifire: string = "OVERVIEW"
  public capsuleMenuList: CapsuleMenuItem[];

  public retailAmountData: RetailAmount;

  public graphSelectedTimePeriod: '7D' | '6M' | 'YTD' | '1Y';
  public localCurrency: string;
  public showLineChart: boolean = false;
  public lineChartData: RetailLineChartDataModel;
  public investmentBalanceVal: number;
  public depositBalanceVal: number;
  private totalAssetsTrendingResponse: TotalAssetsTrendingResponse;
  private totalAssetsTrendingData_7D: TotalAssetDetails[];
  private totalAssetsTrendingData_6M: TotalAssetDetails[];
  private totalAssetsTrendingData_YTD: TotalAssetDetails[];
  private totalAssetsTrendingData_1Y: TotalAssetDetails[];
  public showYtdButton: boolean = true;

  public displayGainLossSection: boolean = true;
  public investmentGainLossResponse: TotalInvestmentGainLossAPIResponse;
  public moneyWeightedReturnsResponse: MoneyWeightedReturnsAPIResponse;
  public accordianData: accordian;
  public accordianData250: accordian;
  public greenColor: string = '#0B6535';
  public lightGreenColor: string = '#D4FCE7';
  public redColor: string = '#AB1912';
  public lightRedColor: string = '#ffbbb8';
  public wealthAnalysis_250BS: boolean = false;
  public gainLossDataIdentifire: number;
  public gainLossInseptionFlag: boolean = false;

  public wealthAnalysis_230BS: boolean = false;
  public wealthAnalysis_230BSidentifire: string = '';
  public BS230OpenedFrom250: boolean = false;

  public displaySpinner: boolean = false;

  constructor(
    private contentService: ContentService,
    private waCommonService: WealthAnalysisCommonService,
    private waApiService: WealthAnalysisAPIService,
    private appService: AppService,
    private appUtils: AppUtils,
    sessionExtService: SessionExtService,
    @Inject('ILoggerService') oLogger: ILoggerService
  ) {
    super(oLogger, sessionExtService);
  }

  ngOnInit() {
    this.displaySpinner = true;
    this.assetBase = this.appService.getAsset();
    this.wealthAnalysisContents = this.contentService.getContentFromStore('wealthanalysis', 'wealthanalysis');
    this.contents200 = this.wealthAnalysisContents.wealthanalysis_200;
    this.contents250 = this.wealthAnalysisContents.wealthanalysis_250;
    this.localCurrency = this.appUtils.getLocalCurrency();

    this.populateCapsuleMenu();
    this.graphSelectedTimePeriod = '7D';
    const currDate: Date = new Date();
    if (currDate.getMonth() === 0) {
      this.showYtdButton = false;
    }
    this.getTotalAssets();
    this.getTotalAssetsTrendingGraph();
    if (this.displayGainLossSection) {
      this.getTotalInvestmentGainLoss_moneyWeightedReturnsFromAPI();
    }
  }

  populateCapsuleMenu() {
    this.capsuleMenuList = this.wealthAnalysisContents.wealthAnalysis_menuButtons['OVERVIEW'];
    if (this.capsuleMenuList) {
      this.capsuleMenuList.forEach(item => {
        item.title_text = this.contents200[item.title_labelId];
      });
    }
  }

  //---------------------------------------TOTAL ASSET----------------------------------
  getTotalAssets() {
    this.investmentBalanceVal = this.waApiService.getInvestmentBalance();
    this.depositBalanceVal = this.waApiService.getDepositBalance();
    const totalAssetsVal: number = this.depositBalanceVal + this.investmentBalanceVal;

    this.retailAmountData = {
      title: this.contents200.Txt_CurrentTotalAssets_Title,
      icon: 'icons/c-20-information.svg',
      amount: this.appUtils.formatCurrencyHelper(this.localCurrency, totalAssetsVal),

      text1: this.contents200.Txt_CurrentTotalAssets_Investment,
      percentage1: (totalAssetsVal ? Math.round(this.investmentBalanceVal * 100 / totalAssetsVal) : 0),
      colorClass1: 'retail-amount-darkChocolate',
      amount1: (totalAssetsVal ? this.appUtils.formatCurrencyHelper('', this.investmentBalanceVal) : ''),

      text2: this.contents200.Txt_CurrentTotalAssets_Deposits,
      percentage2: (totalAssetsVal ? Math.round(this.depositBalanceVal * 100 / totalAssetsVal) : 0),
      colorClass2: 'retail-amount-lightChocolate',
      amount2: (totalAssetsVal ? this.appUtils.formatCurrencyHelper('', this.depositBalanceVal) : '')
    }
  }

  totalAssetIconClicked(evt: boolean): void {
    this.openWealthAnalysis_230BS('CURRENTTOTALASSETS');
  }
  //---------------------------------------TOTAL ASSET----------------------------------

  //---------------------------------------ASSET TRENDING-----------------------------
  graphTimeDurationChange(timePeriod: '7D' | '6M' | 'YTD' | '1Y') {
    this.graphSelectedTimePeriod = timePeriod;
    switch (this.graphSelectedTimePeriod) {
      case '7D':
        this.createChartData(this.totalAssetsTrendingData_7D);
        break;
      case '6M':
        this.createChartData(this.totalAssetsTrendingData_6M);
        break;
      case 'YTD':
        this.createChartData(this.totalAssetsTrendingData_YTD);
        break;
      case '1Y':
        this.createChartData(this.totalAssetsTrendingData_1Y);
        break;
      default:
        break;
    }
  }

  private getTotalAssetsTrendingGraph() {
    this.waApiService.getTotalAssetsTrendingGraph().subscribe((resp: TotalAssetsTrendingResponse) => {
      if (resp) {
        this.totalAssetsTrendingResponse = resp;
        this.totalAssetsTrendingData_7D = resp.totalAssetDetails.filter(item => item.timePeriod === '7D');
        this.createChartData(this.totalAssetsTrendingData_7D);
        this.totalAssetsTrendingData_6M = resp.totalAssetDetails.filter(item => item.timePeriod === '6M');
        this.totalAssetsTrendingData_YTD = resp.totalAssetDetails.filter(item => item.timePeriod === 'YTD');
        this.totalAssetsTrendingData_1Y = resp.totalAssetDetails.filter(item => item.timePeriod === '1Y');
      } else {
        // api error
      }
    })
  }

  private createChartData(totalAssetDetails: TotalAssetDetails[]) {
    this.showLineChart = false;

    let maxYValue: number;
    let maxYValueInvestment: number;
    let maxYValueDeposit: number;

    let monthNames: string[] = this.contents200.Txt_MonthNames;

    let investmentValueList: number[]; // investment value
    let depositValueList: number[]; // deposit value
    let xAxisValueList: string[];
    let tooltip1_valueList: string[];
    let tooltip2_valueList: string[];
    let tooltipChartData: RetailLineChartTooltipData;

    xAxisValueList = totalAssetDetails.map(item => item.processDate);
    if (this.graphSelectedTimePeriod === '7D') {
      xAxisValueList = xAxisValueList.map(processDate => {
        let dateArr: string[] = processDate.split('-');
        let monthIndex: number = Number(dateArr[1]);
        return dateArr[2] + ' ' + monthNames[(monthIndex - 1)];
      });
    } else {
      xAxisValueList = xAxisValueList.map(processDate => {
        let dateArr: string[] = processDate.split('-');
        let monthIndex: number = Number(dateArr[1]);
        return monthNames[(monthIndex - 1)] + ' ' + dateArr[0];
      });
    }


    investmentValueList = totalAssetDetails.map(item => item.investmentAmount);
    depositValueList = totalAssetDetails.map(item => item.depositAmount);

    maxYValueInvestment = _.maxBy(investmentValueList, (item) => {
      return item;
    });
    maxYValueDeposit = _.maxBy(depositValueList, (item) => {
      return item;
    });

    // which ever value is greater use that for Y-axis max value
    if (maxYValueInvestment > maxYValueDeposit) {
      maxYValue = Math.ceil(maxYValueInvestment / 5000) * 5000; // rounded up to the nearest 5k
    } else {
      maxYValue = Math.ceil(maxYValueDeposit / 5000) * 5000; // rounded up to the nearest 5k
    }
    // show Total asset value tooltip
    tooltip1_valueList = totalAssetDetails.map(item => String(item.totalAssetsAmount));
    // Format amount to have currency and comma separator
    tooltip1_valueList = tooltip1_valueList.map(totalAssetsAmount => this.appUtils.formatCurrencyHelper(this.localCurrency, totalAssetsAmount));

    //  show date tooltip
    if (this.graphSelectedTimePeriod === '7D') {
      tooltip2_valueList = totalAssetDetails.map(item => {
        const dateArr: string[] = item.processDate.split('-');
        let monthIndex: number = Number(dateArr[1]);
        return this.contents200.Txt_TotalAssetsTrending_AsOf + ' ' + dateArr[2] + ' ' + monthNames[(monthIndex - 1)] + ' ' + dateArr[0];
      });
    } else {
      tooltip2_valueList = totalAssetDetails.map(item => {
        const dateArr: string[] = item.processDate.split('-');
        let monthIndex: number = Number(dateArr[1]);
        return this.contents200.Txt_TotalAssetsTrending_AsOf + ' ' + monthNames[(monthIndex - 1)] + ' ' + dateArr[0];
      });
    }

    // // Format amount to have currency and comma separator
    // tooltip2_valueList = tooltip2_valueList.map(contributiion => this.currency + ' ' + this.mfpApiService.numberWithCommas(contributiion));
    tooltipChartData = {
      tooltip1_label: '',
      tooltip1_valueList: tooltip1_valueList,
      tooltip2_label: '',
      tooltip2_valueList: tooltip2_valueList,
    }

    this.lineChartData = {
      identifier: 'WealthAnalysis_TotalAssetsTrending',
      xAxisValueList: xAxisValueList,
      yAxisValueList: investmentValueList,
      yAxisValueList2: depositValueList,
      yAxis_maxTicksLimit: maxYValue,
      yAxes_position: 'left',
      tooltipData: tooltipChartData,
      line1BgColor: '#694E15', // Invest
      line2BgColor: '#9C7D3E',// Deposit
      line1AreaFill: true,
      line2AreaFill: true,
      tooltipBgColor: '#EBEFF3',
      tooltipLineColor: '#09131C',
      tooltipTitleFontColor: '#09131C',
      tooltipBodyFontColor: '#5C6974'
    };
    setTimeout(() => {
      this.showLineChart = true;
    }, 0);
  }

  assetTrendingIconClicked(e: Event): void {
    this.openWealthAnalysis_230BS('TOTALASSETTRENDING');
  }
  //---------------------------------------ASSET TRENDING-----------------------------

  //---------------------------------------GAIN & LOSS------------------------------
  private getTotalInvestmentGainLoss_moneyWeightedReturnsFromAPI(): void {
    this.displaySpinner = true;
    let relationshipId = ""; //Keeping it for future use, it is not a mandatory param for these two API
    forkJoin(
      this.waApiService.getTotalInvestmentGainLoss(),
      this.waApiService.getMoneyWeightedReturns()
    ).subscribe(([investmentGainLoss_response, moneyWeightedReturns_response]) => {
      this.investmentGainLossResponse = investmentGainLoss_response;
      this.moneyWeightedReturnsResponse = moneyWeightedReturns_response;
      this.initAccordianData();
      this.displaySpinner = false;
    }, (error) => {
      this.displaySpinner = false;
      //raise common error bottomsheet xxxx
    });
  }

  private initAccordianData(): void {
    let accordianItems: accordianItem[] = [];
    for (let i = 0; i < this.investmentGainLossResponse.totalInvestmentGainOrLoss.length; i++) {
      if (!this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].investmentHoldingFlag) { // another condition of checking

        let GLRealizedPositions: accordianChildItemBreak[] = [];
        if (!this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].realizedGainOrLossFlag) {
          let amountSign: string = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].realizedGainOrLossValue > 0) ? '+' : '-';
          let amountColor: string = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].realizedGainOrLossValue > 0) ? this.greenColor : this.redColor;
          let realizedGL: accordianChildItemBreak = {
            header: this.wealthAnalysisContents.wealthanalysis_250.Txt_GainLoss_InceptionRealizedGL,
            amountSign: amountSign,
            currency: this.investmentGainLossResponse.localCurrencyCode,
            amount: this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].realizedGainOrLossValue,
            amountColor: amountColor
          }
          GLRealizedPositions.push(realizedGL);
        }

        if (!this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].realizedGainOrLossFlag) {
          let amountSign: string = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].realizedCashDividendsCoupons > 0) ? '+' : '-';
          let amountColor: string = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].realizedCashDividendsCoupons > 0) ? this.greenColor : this.redColor;
          let cashDevidentsCoupons: accordianChildItemBreak = {
            header: this.wealthAnalysisContents.wealthanalysis_250.Txt_GainLoss_InceptionCash,
            amountSign: amountSign,
            currency: this.investmentGainLossResponse.localCurrencyCode,
            amount: this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].realizedCashDividendsCoupons,
            amountColor: amountColor
          }
          GLRealizedPositions.push(cashDevidentsCoupons);
        }

        let gainLossCurrentInvHoldings: accordianChildItemBreak[] = [];
        if (!this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].currentGainOrLossFlag) {
          let amountSign: string = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].currentGainOrLossValue > 0) ? '+' : '-';
          let amountColor: string = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].currentGainOrLossValue > 0) ? this.greenColor : this.redColor;
          let unrealizedGL: accordianChildItemBreak = {
            header: this.wealthAnalysisContents.wealthanalysis_250.Txt_GainLoss_InceptionUnrealizedGL,
            amountSign: amountSign,
            currency: this.investmentGainLossResponse.localCurrencyCode,
            amount: this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].currentGainOrLossValue,
            amountColor: amountColor
          }
          gainLossCurrentInvHoldings.push(unrealizedGL);
        }

        if (!this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].currentGainOrLossFlag) {
          let amountSign: string = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].currentCashDividendsCoupons > 0) ? '+' : '-';
          let amountColor: string = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].currentCashDividendsCoupons > 0) ? this.greenColor : this.redColor;
          let cashDevidentsCoupons: accordianChildItemBreak = {
            header: this.wealthAnalysisContents.wealthanalysis_250.Txt_GainLoss_InvCashDividends,
            amountSign: amountSign,
            currency: this.investmentGainLossResponse.localCurrencyCode,
            amount: this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].currentCashDividendsCoupons,
            amountColor: amountColor
          }
          gainLossCurrentInvHoldings.push(cashDevidentsCoupons);
        }

        let accordianChildItems: accordianChildItem[] = [];
        if (!this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].realizedGainOrLossFlag) {
          let amountSign: string = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].realizedGainOrLossTotalValue > 0) ? '+' : '-';
          let amountColor: string = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].realizedGainOrLossTotalValue > 0) ? this.greenColor : this.redColor;
          let GLRealizedPositionsObj: accordianChildItem = {
            childitemHeader: this.wealthAnalysisContents.wealthanalysis_250.Txt_GainLoss_PeriodRealizedPositions,
            info: "GAINLOSSREALIZEDPOSITIONS",
            amountSign: amountSign,
            currency: this.investmentGainLossResponse.localCurrencyCode,
            amount: this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].realizedGainOrLossTotalValue,
            amountColor: amountColor,
            accordianChildItemBreaks: GLRealizedPositions
          }
          accordianChildItems.push(GLRealizedPositionsObj);
        }
        if (!this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].currentGainOrLossFlag) {
          let amountSign: string = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].currentGainOrLossTotalValue > 0) ? '+' : '-';
          let amountColor: string = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].currentGainOrLossTotalValue > 0) ? this.greenColor : this.redColor;
          let gainLossCurrentInvHoldingObj: accordianChildItem = {
            childitemHeader: this.wealthAnalysisContents.wealthanalysis_250.Txt_GainLoss_custPeriodInvHoldings,
            info: "GAINLOSSCURRENTINVESTMENTHOLDINGS",
            amountSign: amountSign,
            currency: this.investmentGainLossResponse.localCurrencyCode,
            amount: this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].currentGainOrLossTotalValue,
            amountColor: amountColor,
            accordianChildItemBreaks: gainLossCurrentInvHoldings
          }
          accordianChildItems.push(gainLossCurrentInvHoldingObj);
        }

        let moneyWeightedReturnsItem: moneyWeightedReturnsItem = this.getMoneyWeightedReturnsNode(this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].timePeriod);
        let amountSign: string = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].gainOrLossValue > 0) ? '+' : '-';
        let amountColor: string = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].gainOrLossValue > 0) ? this.greenColor : this.redColor;
        let percentageSign: string = (moneyWeightedReturnsItem.customerLevel.moneyWeightedReturn > 0) ? '+' : '-';
        let percentageColor: string = (moneyWeightedReturnsItem.customerLevel.moneyWeightedReturn > 0) ? this.greenColor : this.redColor;
        let percentageBgColor: string = (moneyWeightedReturnsItem.customerLevel.moneyWeightedReturn > 0) ? this.lightGreenColor : this.lightRedColor;
        let display: boolean = (this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].timePeriod === 'L12M') ? true : false;
        let totalInvestmentGL: accordianItem = {
          itemHeader: this.wealthAnalysisContents.wealthanalysis_200.Txt_GainLoss_PeriodTitle,
          amountSign: amountSign,
          currency: this.investmentGainLossResponse.localCurrencyCode,
          amount: this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].gainOrLossValue,
          amountColor: amountColor,
          itemAction: "EMMITEVENT", //EXPAND or EMMITEVENT
          percentageSign: percentageSign,
          percentage: moneyWeightedReturnsItem.customerLevel.moneyWeightedReturn + "%",
          percentageColor: percentageColor,
          percentageBgColor: percentageBgColor,
          timeText: this.wealthAnalysisContents.wealthanalysis_200.Txt_MWR_Return + " " + moneyWeightedReturnsItem.customerLevel.moneyWeightedReturnStartDate + " " + this.wealthAnalysisContents.wealthanalysis_200.Txt_MWR_DateTo + " " + moneyWeightedReturnsItem.customerLevel.moneyWeightedReturnEndDate,
          accordianChildItems: accordianChildItems,
          expand: false,
          display: display,
          timePeriod: this.investmentGainLossResponse.totalInvestmentGainOrLoss[i].timePeriod
        }
        accordianItems.push(totalInvestmentGL);
      }
    }

    if (!this.investmentGainLossResponse.depositInterestFlag) { // another condition of checking
      let amountSign: string = (this.investmentGainLossResponse.depositInterestValue > 0) ? '+' : '-';
      let amountColor: string = (this.investmentGainLossResponse.depositInterestValue > 0) ? this.greenColor : this.redColor;
      let interestFromDeposit: accordianItem = {
        itemHeader: this.wealthAnalysisContents.wealthanalysis_200.Txt_DepositsInterests_Text,
        amountSign: amountSign,
        currency: this.investmentGainLossResponse.localCurrencyCode,
        amount: this.investmentGainLossResponse.depositInterestValue,
        amountColor: amountColor,
        itemAction: "EMMITEVENT", //EXPAND or EMMITEVENT
        percentageSign: "",
        percentage: "",
        percentageColor: "",
        percentageBgColor: "",
        timeText: this.investmentGainLossResponse.depositInterestsStartDate + " " + this.wealthAnalysisContents.wealthanalysis_200.Txt_DepositsInterests_DateTo + " " + this.investmentGainLossResponse.depositInterestsEndDate,
        accordianChildItems: [],
        expand: false,
        display: true,
        timePeriod: ""
      }
      accordianItems.push(interestFromDeposit);
    }

    this.accordianData = {
      header: this.wealthAnalysisContents.wealthanalysis_200.Txt_GainLoss_Title,
      displayChevron: true,
      accordianItems: accordianItems
    }
    this.accordianData250 = {
      header: '',
      displayChevron: false,
      accordianItems: accordianItems
    }
    //console.log("accordianObj at 200 :", this.accordianData);
  }

  private getMoneyWeightedReturnsNode(timePeriod: string): moneyWeightedReturnsItem {
    let moneyWeightedReturnsItem: moneyWeightedReturnsItem;
    for (let i = 0; i < this.moneyWeightedReturnsResponse.moneyWeightedReturns.length; i++) {
      if (this.moneyWeightedReturnsResponse.moneyWeightedReturns[i].moneyWeightedReturnType === timePeriod) {
        moneyWeightedReturnsItem = this.moneyWeightedReturnsResponse.moneyWeightedReturns[i];
        break;
      }
    }
    return moneyWeightedReturnsItem;
  }

  public accordianButtonAction(itemId: number) {
    this.gainLossDataIdentifire = itemId;
    this.openWealthAnalysis_250BS();
  }

  public openWealthAnalysis_250BS() {
    this.initAccordianData250();
    this.wealthAnalysis_250BS = true;
  }

  public closeWealthAnalysis_250BS(e: Event) {
    this.wealthAnalysis_250BS = false;
    this.initAccordianData();
  }

  public emitClickOutsideToCloseWealthAnalysis_250BS(e) {
    this.wealthAnalysis_250BS = e;
  }

  private initAccordianData250() {
    for (let i = 0; i < this.accordianData250.accordianItems.length; i++) {
      if (!this.gainLossInseptionFlag) { // for 12 Months
        if (this.accordianData250.accordianItems[i].timePeriod === "L12M") {
          this.accordianData250.accordianItems[i].display = true;
          this.accordianData250.accordianItems[i].expand = true;
        } else {
          this.accordianData250.accordianItems[i].display = false;
        }
      } else if (this.gainLossInseptionFlag) { // for Inseption
        if (this.accordianData250.accordianItems[i].timePeriod === "SI") {
          this.accordianData250.accordianItems[i].display = true;
          this.accordianData250.accordianItems[i].expand = true;
        } else {
          this.accordianData250.accordianItems[i].display = false;
        }
      }
    }
    this.waCommonService.gainLoss250DataService = this.accordianData250; // not needed if 250 is not in use.
  }

  public onClickWA250Button(e: TouchEvent, i: string) {
    if (i === 'L12M') {
      this.gainLossInseptionFlag = false;
    } else if (i === 'SI') {
      this.gainLossInseptionFlag = true;
    }
    this.initAccordianData250();
  }

  public retailAccordianInfoBtnClick(e: string) {
    this.BS230OpenedFrom250 = true;
    let evt: TouchEvent;
    this.closeWealthAnalysis_250BS(evt);
    this.openWealthAnalysis_230BS(e);
  }
  //---------------------------------------GAIN & LOSS-----------------------------

  //--------------------------------------- 230 -----------------------------------
  public openWealthAnalysis_230BS(identifire: string) {
    this.wealthAnalysis_230BS = true;
    this.wealthAnalysis_230BSidentifire = identifire;
  }

  public closeWealthAnalysis_230BS(e: Event) {
    this.wealthAnalysis_230BS = false;
    if (this.BS230OpenedFrom250) {
      this.openWealthAnalysis_250BS();
      this.BS230OpenedFrom250 = false;;
    }
  }

  public emitClickOutsideToCloseWealthAnalysis_230BS(e) {
    this.wealthAnalysis_230BS = e;
  }
  //--------------------------------------- 230 -----------------------------------
}
