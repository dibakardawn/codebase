import { Component, Inject, Input, OnChanges, Output, EventEmitter, ElementRef } from '@angular/core';
import { ILoggerService } from '@citi-gcg-167407/core-services'
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'wealth-analysis-header',
  templateUrl: './wealth-analysis-header.component.html',
  styleUrls: ['./wealth-analysis-header.component.scss']
})
export class WealthAnalysisHeader implements OnChanges {
  @Input() public headerText: string;
  public assetBase: string = '';

  constructor(
    private appService: AppService,
    @Inject('ILoggerService') private oLogger: ILoggerService
  ) { }

  ngOnChanges() {
    this.assetBase = this.appService.getAsset();
    //console.log("tabMenuObject : ", this.tabMenuObject);
  }
  onBack(): void {
    this.appService.backToOdyssey();
  }
}
