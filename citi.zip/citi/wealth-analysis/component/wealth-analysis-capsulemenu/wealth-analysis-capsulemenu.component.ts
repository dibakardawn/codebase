import { Component, Input, OnInit, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { GmHelpersService } from '@citi-gcg-167407/common';
import { AppService } from 'src/app/app.service';

import { CapsuleMenuItem } from '../../models/wealth-analysis.model';
import { AppStore } from '@citi-gcg-167407/core-services';

@Component({
  selector: 'wealth-analysis-capsulemenu',
  templateUrl: './wealth-analysis-capsulemenu.component.html',
  styleUrls: ['./wealth-analysis-capsulemenu.component.scss']
})
export class WealthAnalysisCapsuleMenu implements OnInit, AfterViewInit {
  @Input() public capsuleMenuList: CapsuleMenuItem[];
  public assetBase: string = '';
  private touchStartX: number = 0;
  private touchStartY: number = 0;
  private touchStartTime: number = 0;

  constructor(
    private appService: AppService,
    private router: Router,
    private appStore: AppStore,
    private gmHelpersService: GmHelpersService
  ) { }

  ngOnInit() {
    this.assetBase = this.appService.getAsset();
  }

  ngAfterViewInit() {
    let customerSegment: string = '';
    if (this.appStore.getCustomerProfile()) {
      customerSegment = this.appStore.getCustomerProfile().customerSegment;
    }
    this.capsuleMenuList.forEach(item => {
      if (item.rule && item.rule.validCustomerSegments) {
        let customerSegRule: string = item.rule.validCustomerSegments;
        let customerSegRuleList: string[] = customerSegRule.split(',').map(item => item.trim());
        if (customerSegRuleList.includes(customerSegment)) {
          item.display = true;
        } else {
          item.display = false;
        }
      }
    })
  }
  menuClickHandler(e: TouchEvent, item: CapsuleMenuItem) {
    if (this.checkBeforeClickEventX(e)) {
      switch (item.eventType) {
        case 'GM':
          this.gmHelpersService.showGMFunction(item.eventName);
          break;
        case 'M63':
          this.router.navigate([item.eventName]);
          break;
        default:
          break;
      }
    }
  }

  public TouchStartReader(event: TouchEvent): void {
    this.touchStartX = event.touches[0].clientX;
    this.touchStartY = event.touches[0].clientY;
    this.touchStartTime = event.timeStamp;
  }

  public checkBeforeClickEventX(event: TouchEvent): boolean {
    const endTouchX: number = event.changedTouches[0].clientX;
    const endTouchY: number = event.changedTouches[0].clientY;
    const endTouchTime: number = event.timeStamp;
    if (Math.abs(Number(endTouchX - this.touchStartX)) > 5 || Number(endTouchTime - this.touchStartTime) > 400) {
      return false;
    } else {
      return true;
    }
  }

}
