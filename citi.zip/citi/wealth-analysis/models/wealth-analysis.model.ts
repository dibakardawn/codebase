/*-------------------Capsule Menu--------------------------------------*/
export interface CapsuleMenuItem {
  title_text: string;
  title_labelId: string;
  icon: string;
  eventName: string;
  eventType: string;
  display: boolean;
  rule?: CapsuleMenuItemRule;
}
export interface CapsuleMenuItemRule {
  validCustomerSegments?: string;
}
/*-------------------Capsule Menu--------------------------------------*/

/*-------------------Wealth Analysis Assets Trending Response------------*/
export interface TotalAssetsTrendingRequest {
  sevenDaysTimePeriodFlag: boolean;
  sixMonthsTimePeriodFlag: boolean;
  yearToDateTimePeriodFlag: boolean;
  oneYearTimePeriodFlag: boolean;
}

export interface TotalAssetsTrendingResponse {
  localCurrencyCode: string;
  totalAssetDetails: TotalAssetDetails[];
}

export interface TotalAssetDetails {
  processDate: string;
  timePeriod: string;
  totalAssetsAmount: number;
  investmentAmount: number;
  depositAmount: number;
}
/*-------------------Wealth Analysis Assets Trending Response------------*/

/*-------------------Total Investment Gain API Response Structures-------*/
export interface TotalInvestmentGainLossAPIResponse {
  localCurrencyCode: string,
  totalInvestmentGainOrLoss: totalInvestmentGainOrLossItem[],
  depositInterestFlag: boolean,
  depositInterestValue: number,
  depositInterestsStartDate: string,
  depositInterestsEndDate: string,
  relationshipGainOrLossDetails?: relationshipGainOrLossItem[]
}

export interface totalInvestmentGainOrLossItem {
  timePeriod: string,
  investmentHoldingFlag: boolean,
  gainOrLossValue: number,
  realizedGainOrLossFlag: boolean,
  realizedGainOrLossTotalValue: number,
  realizedGainOrLossValue: number,
  realizedCashDividendsCoupons: number,
  currentGainOrLossFlag: boolean,
  currentGainOrLossTotalValue: number,
  currentGainOrLossValue: number,
  currentCashDividendsCoupons: number
}

export interface relationshipGainOrLossItem {
  displayRelationshipNumber: string,
  relationshipId: string,
  localCurrencyInvestmentAmount: number,
  toDateInvestmentAmount: string,
  totalInvestmentGainOrLossDetails: totalInvestmentGainOrLossDetailsItem[]
}

export interface totalInvestmentGainOrLossDetailsItem { //xxxx similar to TotalInvestmentGainOrLossItem
  gainOrLossTimePeriod: string, // timePeriod xxxx
  investmentHoldingFlag: boolean,
  totalInvestmentGainLossValue: number, //gainOrLossValue xxxx
  realizedGainOrLossFlag: boolean,
  realizedGainOrLossTotalValue: number,
  realizedGainOrLossValue: number,
  realizedCashDividendsCoupons: number,
  currentGainOrLossFlag: boolean,
  currentGainOrLossTotalValue: number,
  currentGainOrLossValue: number,
  currentCashDividendsCoupons: number
}
/*-------------------Total Investment Gain API Response Structures-------*/

/*-------------------Money Weighted Returns API Response Structures------*/
export interface MoneyWeightedReturnsAPIResponse {
  moneyWeightedReturns: moneyWeightedReturnsItem[]
}

export interface moneyWeightedReturnsItem {
  moneyWeightedReturnType: string,
  customerLevel: CustomerLevelObject,
  relationshipLevel?: relationshipLevelObject
}

export interface CustomerLevelObject {
  moneyWeightedReturn: number,
  moneyWeightedReturnStartDate: string,
  moneyWeightedReturnEndDate: string
}

export interface relationshipLevelObject {
  moneyWeightedList: moneyWeightedListItem[]
}

export interface moneyWeightedListItem {
  relationshipId: string,
  displayRelationshipNumber: string,
  moneyWeightedReturn: number,
  moneyWeightedReturnStartDate: string,
  moneyWeightedReturnEndDate: string
}
/*-------------------Money Weighted Returns API Response Structures------*/

/*-------------------Deposit Products API Response Structures------------*/
export interface DepositProductsAPIResponse {
  localCurrencyCode: string,
  depositsSummary: depositsSummaryItem[]
}

export interface depositsSummaryItem {
  processDate: string,
  totalAmount: number,
  productCurrencyBreakdownList: productCurrencyBreakdownListItem[]
}

export interface productCurrencyBreakdownListItem {
  productCurrencyCode: string,
  productCurrencyAmount: number,
  localCurrencyCode: string,
  localCurrencyAmount: number
}
/*-------------------Deposit Products API Response Structures------------*/

/*-------------------Wealth Analysis constants---------------------------*/
export class wealthAnalysisConstants {
  public static Preprocess_ErrorCodes = ['marginCallIssued', 'resourceNotFound'];
}
/*-------------------Wealth Analysis constants---------------------------*/
