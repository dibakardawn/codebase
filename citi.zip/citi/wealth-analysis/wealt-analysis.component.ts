import { Component } from '@angular/core';

@Component({
  selector: 'wealth-analysis',
  template: '<router-outlet></router-outlet>'
})
export class WealthAnalysisComponent { }
