import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CitiCommonModule } from '@citi-gcg-167407/common';
import { ButtonModule, BottomSheetModule, SwitchModule } from '@citi-gcg-167407/core-uiux';

import { WealthAnalysisRoutingModule } from './wealth-analysis-routing.module';
import { WealthAnalysisComponent } from './wealt-analysis.component';

import { WealthAnalysisHeader } from './component/wealth-analysis-header/wealth-analysis-header.component';
import { WealthAnalysisCapsuleMenu } from './component/wealth-analysis-capsulemenu/wealth-analysis-capsulemenu.component';
import { RetailCommonModule } from '../retail-common/retail-common.module';

import { WealthAnalysisMainComponent } from './wealth-analysis-main/wealth-analysis-main.component';
import { WealthAnalysis200Component } from './wealth-analysis-200/pages/wealth-analysis-200.component';
import { WealthAnalysis230Component } from './wealth-analysis-230/pages/wealth-analysis-230.component';
import { WealthAnalysis250Component } from './wealth-analysis-250/pages/wealth-analysis-250.component';
import { WealthAnalysis300Component } from './wealth-analysis-300/pages/wealth-analysis-300.component';
import { WealthAnalysis400Component } from './wealth-analysis-400/pages/wealth-analysis-400.component';

import { WealthAnalysisAPIService } from './services/wealth-analysis-api.service';
import { WealthAnalysisCommonService } from './services/wealth-analysis-common.service';
import { DvpMutualFundPortfolioModuleIntro } from '../dvp-mutual-fund-portfolio-intro/mutual-fund-portfolio.module';
@NgModule({
  imports: [
    CommonModule,
    HttpModule,
    FormsModule,
    CitiCommonModule,
    WealthAnalysisRoutingModule,
    ButtonModule.forRoot(),
    BottomSheetModule.forRoot(),
    SwitchModule,
    ReactiveFormsModule,
    RetailCommonModule,
    DvpMutualFundPortfolioModuleIntro
  ],
  declarations: [
    WealthAnalysisComponent,
    WealthAnalysis200Component,
    WealthAnalysis230Component,
    WealthAnalysis250Component,
    WealthAnalysis300Component,
    WealthAnalysis400Component,
    WealthAnalysisMainComponent,
    WealthAnalysisHeader,
    WealthAnalysisCapsuleMenu
  ],
  exports: [],
  providers: [
    WealthAnalysisAPIService,
    WealthAnalysisCommonService
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA
  ]
})
export class WealthAnalysisModule { }
