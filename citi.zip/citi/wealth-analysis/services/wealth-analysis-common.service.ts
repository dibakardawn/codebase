import { Injectable } from '@angular/core';

import { accordian } from 'src/apps/retail-common/model/retail-accordian.model';

@Injectable()
export class WealthAnalysisCommonService {
  public isNative = false;
  constructor(
  ) { }

  private _gainLoss250Data: accordian;

  public set gainLoss250DataService(accordianData: accordian) {
    this._gainLoss250Data = accordianData;
  }

  public get gainLoss250DataService() {
    return this._gainLoss250Data;
  }
}
