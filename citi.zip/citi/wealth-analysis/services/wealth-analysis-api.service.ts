import { Injectable, Inject } from '@angular/core';
import { ILoggerService, IPrettyLogger, AppStore } from '@citi-gcg-167407/core-services';
import { AppController, AccountProfile, AppUtils } from '@citi-gcg-167407/common';
import { throwError as observableThrowError, Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

import { TotalAssetsTrendingRequest, TotalAssetsTrendingResponse, TotalInvestmentGainLossAPIResponse, MoneyWeightedReturnsAPIResponse, wealthAnalysisConstants, DepositProductsAPIResponse } from '../models/wealth-analysis.model';

@Injectable()
export class WealthAnalysisAPIService {
  private prettyLogger: IPrettyLogger;
  private localCurrency: string;
  constructor(
    private appStore: AppStore,
    private appController: AppController,
    private appUtils: AppUtils,
    @Inject('ILoggerService') logger: ILoggerService
  ) {
    this.localCurrency = this.appUtils.getLocalCurrency();
    this.prettyLogger = logger.prettyLogger('wealthAnalysis API Service');
  }

  private checkSuccessStatus(response): boolean {
    return response && response.rs && response.rs.success && response.rs.rsData;
  }

  private specificErr(errorResp: any, specificErrorArray: string[]): boolean {
    return errorResp.rs && errorResp.rs.errorData && errorResp.rs.errorData.code && specificErrorArray.indexOf(errorResp.rs.errorData.code) !== -1;
  }

  private getSpecificErr(error: any, TAG: string): Observable<any> {
    let errorResp;
    try {
      errorResp = typeof error.body === 'string' ? JSON.parse(error.body) : undefined;
    } catch (error) {
      this.prettyLogger.error(TAG, 'Encounter error when parse error.body');
      return of(false);
    }

    if (errorResp && this.specificErr(errorResp, wealthAnalysisConstants.Preprocess_ErrorCodes)) {
      error.code = errorResp.rs.errorData.code;
      return of(error);
    } else {
      this.prettyLogger.error(TAG, 'Server Error');
      return of(false);
    }
  }

  public getDepositBalance(): number {
    const depositAccData: AccountProfile = this.appStore.getCustomerProfile().accountClusters.find(accountCluster => accountCluster.catagoryCode === '1');
    let depositBalanceVal: number = 0;
    if (depositAccData && depositAccData.totalBalance) {
      let depositBalance: string = depositAccData.totalBalance;
      depositBalance = depositBalance.split('S$').join('').trim();
      depositBalance = depositBalance.split(this.localCurrency).join('').trim();
      depositBalance = depositBalance.split(',').join('');
      depositBalanceVal = Number(depositBalance);
    }
    return depositBalanceVal;
  }

  public getInvestmentBalance(): number {
    const investmentAccData: AccountProfile = this.appStore.getCustomerProfile().accountClusters.find(accountCluster => accountCluster.catagoryCode === '2');
    let investmentBalanceVal: number = 0;
    if (investmentAccData && investmentAccData.totalBalance) {
      let investmentBalance: string = investmentAccData.totalBalance;
      investmentBalance = investmentBalance.split('S$').join('').trim();
      investmentBalance = investmentBalance.split(this.localCurrency).join('').trim();
      investmentBalance = investmentBalance.split(',').join('');
      investmentBalanceVal = Number(investmentBalance);
    }
    return investmentBalanceVal;
  }

  public getTotalAssetsTrendingGraph(): Observable<TotalAssetsTrendingResponse> {
    const TAG = 'getTotalAssetsTrendingGraph()';
    // let mock: TotalAssetsTrendingResponse =
    // {
    //   "localCurrencyCode": "SGD",
    //   "totalAssetDetails": [
    //     {
    //       "processDate": "2020-01-01",
    //       "timePeriod": "7D",
    //       "totalAssetsAmount": 6000000.12,
    //       "investmentAmount": 40000.12,
    //       "depositAmount": 50000.12
    //     },
    //     {
    //       "processDate": "2020-01-02",
    //       "timePeriod": "7D",
    //       "totalAssetsAmount": 6000000.12,
    //       "investmentAmount": 45000.12,
    //       "depositAmount": 55000.12
    //     },
    //     {
    //       "processDate": "2020-01-03",
    //       "timePeriod": "7D",
    //       "totalAssetsAmount": 6000000.12,
    //       "investmentAmount": 55000.12,
    //       "depositAmount": 60000.12
    //     },
    //     {
    //       "processDate": "2020-01-04",
    //       "timePeriod": "7D",
    //       "totalAssetsAmount": 6000000.12,
    //       "investmentAmount": 75000.12,
    //       "depositAmount": 80000.12
    //     },
    //     {
    //       "processDate": "2020-01-05",
    //       "timePeriod": "7D",
    //       "totalAssetsAmount": 6000000.12,
    //       "investmentAmount": 80000.12,
    //       "depositAmount": 85000.12
    //     },
    //     {
    //       "processDate": "2020-01-06",
    //       "timePeriod": "7D",
    //       "totalAssetsAmount": 6000000.12,
    //       "investmentAmount": 90000.12,
    //       "depositAmount": 95000.12
    //     },
    //     {
    //       "processDate": "2020-01-07",
    //       "timePeriod": "7D",
    //       "totalAssetsAmount": 6000000.12,
    //       "investmentAmount": 95000.12,
    //       "depositAmount": 99000.12
    //     },
    //     {
    //       "processDate": "2020-01-01",
    //       "timePeriod": "6M",
    //       "totalAssetsAmount": 6000000.12,
    //       "investmentAmount": 40000.12,
    //       "depositAmount": 30000.12
    //     },
    //     {
    //       "processDate": "2020-02-02",
    //       "timePeriod": "6M",
    //       "totalAssetsAmount": 6000000.12,
    //       "investmentAmount": 45000.12,
    //       "depositAmount": 35000.12
    //     },
    //     {
    //       "processDate": "2020-03-03",
    //       "timePeriod": "6M",
    //       "totalAssetsAmount": 6000000.12,
    //       "investmentAmount": 60000.12,
    //       "depositAmount": 50000.12
    //     },
    //     {
    //       "processDate": "2020-04-04",
    //       "timePeriod": "6M",
    //       "totalAssetsAmount": 6000000.12,
    //       "investmentAmount": 70000.12,
    //       "depositAmount": 60000.12
    //     },
    //     {
    //       "processDate": "2020-05-05",
    //       "timePeriod": "6M",
    //       "totalAssetsAmount": 6000000.12,
    //       "investmentAmount": 78000.12,
    //       "depositAmount": 75000.12
    //     },
    //     {
    //       "processDate": "2020-06-06",
    //       "timePeriod": "6M",
    //       "totalAssetsAmount": 6000000.12,
    //       "investmentAmount": 90000.12,
    //       "depositAmount": 80000.12
    //     }
    //   ]
    // }
    // return of(mock);
    const currDate: Date = new Date();
    const reqParam: any = {};
    const reqObject: TotalAssetsTrendingRequest = {
      sevenDaysTimePeriodFlag: true,
      sixMonthsTimePeriodFlag: true,
      yearToDateTimePeriodFlag: (currDate.getMonth() === 0) ? false : true,
      oneYearTimePeriodFlag: true
    };
    reqParam.queryParam = reqObject;
    return this.appController.post('wealthAnalysis', 'totalInvestmentAssets', reqParam)
      .pipe(
        map((response) => {
          if (this.checkSuccessStatus(response)) {
            return response.rs.rsData;
          } else {
            return null;
          }
        }),
        catchError((error: any) => {
          this.prettyLogger.error(TAG, 'Server Error');
          return of(null);
        })
      );
  }

  public getTotalInvestmentGainLoss(relationshipId?: string): Observable<TotalInvestmentGainLossAPIResponse> {
    const TAG = 'apiTotalInvestmentGainLoss : ';
    const reqParam: any = {};
    let reqData: any = relationshipId;
    reqParam.uriParam = [relationshipId];
    //reqParam.queryParam = reqData;
    return this.appController.post('wealthAnalysis', 'totalInvestmentGainLoss', {}, reqParam)
      .pipe(
        map((response) => {
          if (this.checkSuccessStatus(response)) {
            return response.rs.rsData;
          } else if (response.rs.rsData === null) {
            return null;
          }
        }),
        catchError((error: any) => {
          return this.getSpecificErr(error, TAG);
        })
      );
  }

  public getMoneyWeightedReturns(relationshipId?: string): Observable<MoneyWeightedReturnsAPIResponse> {
    const TAG = 'apiMoneyWeightedReturns : ';
    const reqParam: any = {};
    let reqData: any = relationshipId;
    reqParam.uriParam = [relationshipId];
    //reqParam.queryParam = reqData;
    return this.appController.post('wealthAnalysis', 'moneyWeightedReturn', {}, reqParam)
      .pipe(
        map((response) => {
          if (this.checkSuccessStatus(response)) {
            return response.rs.rsData;
          } else if (response.rs.rsData === null) {
            return null;
          }
        }),
        catchError((error: any) => {
          return this.getSpecificErr(error, TAG);
        })
      );
  }

  public getDepositProducts(): Observable<DepositProductsAPIResponse> {
    const TAG = 'apiDepositProducts : ';
    // API GET CALL: To get any existing knowledge and experience
    return this.appController.post('wealthAnalysis', 'depositProductsSumary', {}, {})
      .pipe(
        map((response) => {
          if (this.checkSuccessStatus(response)) {
            return response.rs.rsData;
          } else if (response.rs.rsData === null) {
            return null;
          }
        }),
        catchError((error: any) => {
          let errorResp;
          try {
            errorResp = typeof error.body === 'string' ? JSON.parse(error.body) : undefined;
          } catch (error) {
            this.prettyLogger.error(TAG, 'Encounter error when parse error.body');
            return of(false);
          }
          if (errorResp && this.specificErr(errorResp, wealthAnalysisConstants.Preprocess_ErrorCodes)) {
            error.code = errorResp.rs.errorData.code;
            return of(error);
          } else {
            this.prettyLogger.error(TAG, 'Server Error');
            return of(false);
          }
        })
      );
  }

}
