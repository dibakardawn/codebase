export interface accordian {
  header: string,
  displayChevron: boolean,
  accordianItems: accordianItem[]
}

export interface accordianItem {
  itemHeader: string,
  amountSign: string,
  currency: string,
  amount: number,
  amountColor: string,
  itemAction: string, //If comes EXPAND or EMMITEVENT, then it will expand the child items & can emmit event to parent
  percentageSign: string,
  percentage: string,
  percentageColor: string,
  percentageBgColor: string,
  timeText: string,
  accordianChildItems: accordianChildItem[],
  expand: boolean, //It will show the down chevron if it is true.
  display: boolean, //It will show/hide whole the section.
  timePeriod: string
}

export interface accordianChildItem {
  childitemHeader: string,
  info: string,
  amountSign: string,
  currency: string,
  amount: number,
  amountColor: string,
  accordianChildItemBreaks: accordianChildItemBreak[]
}

export interface accordianChildItemBreak {
  header: string,
  amountSign: string,
  currency: string,
  amount: number,
  amountColor: string
}
