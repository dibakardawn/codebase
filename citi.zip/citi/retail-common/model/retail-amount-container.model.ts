export interface RetailAmount {
  title: string;
  icon: string;
  amount: string;
  text1: string;
  percentage1: number;
  colorClass1: string;
  amount1: string;
  amount2: string;
  text2: string
  percentage2: number;
  colorClass2: string;
}
