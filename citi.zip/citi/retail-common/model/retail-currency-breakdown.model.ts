export interface currencyItem {
  currency: string,
  amount: number,
  percentage: number
}
