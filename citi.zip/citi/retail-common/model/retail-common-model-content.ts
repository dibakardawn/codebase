export class CommonICContentListDetails {
    customerAssociatedTags: string;
    sequenceNumber?: number;
    photoImageUrl?: string;
    contentTitle: string;
    contentCategory: string;
    contentPublishedDate: string;
    contentId: string;
    favouriteFlag: boolean;
    uniqueReferenceId?: string;
    contextId?: string;
    flow?: string;
    relayState?: string;
    contentSource?: string;
    typeOfContent?: string;
  }