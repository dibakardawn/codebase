export interface barGraphItem {
  currency: string,
  amount: number,
  tooltipText: string,
  percentage: number,
  btnText: string
}
