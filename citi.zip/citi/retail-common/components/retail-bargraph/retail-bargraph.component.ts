import { Component, Inject, Input, ViewChild, OnChanges, Output, EventEmitter, ElementRef } from '@angular/core';
import { ILoggerService } from '@citi-gcg-167407/core-services'
import { AppService } from 'src/app/app.service';

import { barGraphItem } from '../../model/retail-bargraph.model';

@Component({
  selector: 'retail-bargraph',
  templateUrl: './retail-bargraph.component.html',
  styleUrls: ['./retail-bargraph.component.scss']
})
export class Retailbargraph implements OnChanges {
  @Input() public bargraphInput: barGraphItem[];
  @ViewChild('currencyBreakdownGraphArea') currencyBreakdownGraphAreaObject;
  public GraphAreaVW: number = 100;
  public tooltipCurrency: string;
  public tooltipAmount: number;
  public tooltipText: string;
  public tooltipLeftMargin: number = 1.33; //5px initially
  public tabName: string = '';
  public barItemW: number = 16; //in VW - 60px per item
  private touchStartX: number = 0;
  private touchStartY: number = 0;
  private touchStartTime: number = 0;

  constructor(
    private appService: AppService,
    @Inject('ILoggerService') private oLogger: ILoggerService
  ) { }

  ngOnChanges() {
    console.log("bargraphInput : ", this.bargraphInput);
    this.barGraphAreaWidthCalc();
    setTimeout(() => {
      if (this.currencyBreakdownGraphAreaObject) {
        const scrollOne = this.currencyBreakdownGraphAreaObject.nativeElement as HTMLElement;
        scrollOne.scrollLeft = scrollOne.scrollWidth;
      }
    }, 10);
  }

  barGraphAreaWidthCalc() {
    if (this.bargraphInput) {
      if (this.bargraphInput.length > 5) {
        let berGraphItemCount: number = this.bargraphInput.length;
        this.GraphAreaVW = +(this.barItemW * berGraphItemCount) + 7; //26px extra for tooltip
      }
    }
  }

  public tabswitch(event: TouchEvent, name: string) {
    if (this.checkBeforeClickEvent(event)) {
      this.tabName = name;
      let barIndex: number = 0;
      for (let i = 0; i < this.bargraphInput.length; i++) {
        if (this.bargraphInput[i].btnText === name) {
          this.tooltipCurrency = this.bargraphInput[i].currency;
          this.tooltipAmount = this.bargraphInput[i].amount;
          this.tooltipText = this.bargraphInput[i].tooltipText;
          barIndex = i;
        }
      }
      if ((barIndex - 1) > 0) {
        this.tooltipLeftMargin = (((barIndex - 1) * this.barItemW) + 8); //8vw added to make it center;
      } else if (barIndex === (this.bargraphInput.length - 1)) {
        this.tooltipLeftMargin = ((barIndex - 1) * this.barItemW); //8vw is not added for the last item
      } else {
        this.tooltipLeftMargin = 1.33; //5px initially
      }
    }
  }

  public TouchStartReader(event: TouchEvent): void {
    this.touchStartX = event.touches[0].clientX;
    this.touchStartY = event.touches[0].clientY;
    this.touchStartTime = event.timeStamp;
  }

  public checkBeforeClickEvent(event: TouchEvent): boolean {
    const endTouchX: number = event.changedTouches[0].clientX;
    // const endTouchY: number = event.changedTouches[0].clientY;
    // const endTouchTime: number = event.timeStamp;
    if (Math.abs(Number(endTouchX - this.touchStartX)) > 5) {
      return false;
    } else {
      return true;
    }
  }

}
