import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AppService } from 'src/app/app.service';

import { accordian } from '../../model/retail-accordian.model'

@Component({
  selector: 'retail-accordian',
  templateUrl: './retail-accordian.component.html',
  styleUrls: ['./retail-accordian.component.scss']
})
export class RetailAccordianComponent implements OnInit {
  @Input() accordianData: accordian;
  @Output() retailAccordianButtonEmmiter: EventEmitter<number> = new EventEmitter();
  @Output() retailAccordianInfoBtnEmmiter: EventEmitter<string> = new EventEmitter();
  public assetBase: string;
  public numOfDisplayableItems: number = 0;

  constructor(
    private appService: AppService
  ) { }

  ngOnInit() {
    this.assetBase = this.appService.getAsset();
    let accordianDataInterval = setInterval(() => {
      if (this.accordianData) {
        //console.log("accordianData at retail accordian : ", this.accordianData);
        for (let i = 0; i < this.accordianData.accordianItems.length; i++) {
          if (this.accordianData.accordianItems[i].display) {
            this.numOfDisplayableItems++;
          }
        }
        clearInterval(accordianDataInterval);
      }
    }, 100);

  }

  onClickAccordianButton(e: TouchEvent, index: number): void {
    for (let i = 0; i < this.accordianData.accordianItems.length; i++) {
      if (i === index) {
        if (this.accordianData.accordianItems[i].itemAction === 'EXPAND') {
          if (!this.accordianData.accordianItems[i].expand) {
            this.accordianData.accordianItems[i].expand = true;
          } else {
            this.accordianData.accordianItems[i].expand = false;
          }
        } else {
          this.retailAccordianButtonEmmiter.emit(index);
        }
      } else {
        this.accordianData.accordianItems[i].expand = false;
      }
    }
  }

  infoIconClick(info: string): void {
    this.retailAccordianInfoBtnEmmiter.emit(info);
  }

}
