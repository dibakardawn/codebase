import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AppService } from 'src/app/app.service';

@Component({
  selector: 'retail-error-drawer',
  templateUrl: './retail-error-drawer.component.html',
  styleUrls: ['./retail-error-drawer.component.scss']
})
export class RetailErrorDrawerComponent implements OnInit {
  @Input() showDrawer: boolean;
  @Input() showErrorIcon: boolean = true;
  @Input() errTitle: string;
  @Input() errDesc: string;
  @Input() btnPrimaryLabel: string;
  @Input() clickOutsideToClose: boolean = true;
  @Output() btnPrimaryClick: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() drawerClosed: EventEmitter<boolean> = new EventEmitter<boolean>();
  public assetBase: string;

  constructor(
    private appService: AppService
  ) { }

  ngOnInit() {
    this.assetBase = this.appService.getAsset();
  }

  public resetContent(e: boolean) {
    if (!e) {
      this.showDrawer = e;
      this.drawerClosed.emit(true);
    }
  }

  public onBtnPrimaryClick() {
    this.btnPrimaryClick.emit(true);
  }
}
