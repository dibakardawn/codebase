import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { AppService } from 'src/app/app.service';
import { RetailAmount } from '../../model/retail-amount-container.model'

@Component({
  selector: 'retail-amount-container',
  templateUrl: './retail-amount-container.component.html',
  styleUrls: ['./retail-amount-container.component.scss']
})
export class RetailAmountContainerComponent implements OnInit {
  @Input() retailAmountInput: RetailAmount;
  @Output() iconClick: EventEmitter<boolean> = new EventEmitter<boolean>();
  public assetBase: string;

  constructor(
    private appService: AppService
  ) { }

  ngOnInit() {
    this.assetBase = this.appService.getAsset();
  }
  iconClicked() {
    this.iconClick.emit(true);
  }
}
