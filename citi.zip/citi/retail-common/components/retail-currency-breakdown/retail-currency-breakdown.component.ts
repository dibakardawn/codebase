import { Component, Inject, Input, ViewChild, OnChanges, Output, EventEmitter, ElementRef } from '@angular/core';
import { ILoggerService } from '@citi-gcg-167407/core-services'
import { AppService } from 'src/app/app.service';

import { currencyItem } from '../../model/retail-currency-breakdown.model';

@Component({
  selector: 'retail-currency-breakdown',
  templateUrl: './retail-currency-breakdown.component.html',
  styleUrls: ['./retail-currency-breakdown.component.scss']
})
export class RetailCurrencyBreakdown implements OnChanges {
  @Input() public RetailCurrencyBreakdownInput: currencyItem[];
  public assetBase: string = '';

  constructor(
    private appService: AppService,
    @Inject('ILoggerService') private oLogger: ILoggerService
  ) { }

  ngOnChanges() {
    this.assetBase = this.appService.getAsset();
  }

}
