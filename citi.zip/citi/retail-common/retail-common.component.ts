import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'retail-common',
  templateUrl: './retail-common.component.html'
})
export class RetailCommonComponent implements OnInit {

  constructor() { }

  ngOnInit() { }
}
