import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { CitiCommonModule } from '@citi-gcg-167407/common';
import { BottomSheetModule, ButtonModule } from '@citi-gcg-167407/core-uiux';
import { RetailErrorDrawerComponent } from './components/retail-error-drawer/retail-error-drawer.component';
import { RetailAmountContainerComponent } from './components/retail-amount-container/retail-amount-container.component';
import { RetailAccordianComponent } from './components/retail-accordian/retail-accordian.component';
import { Retailbargraph } from './components/retail-bargraph/retail-bargraph.component';
import { RetailCurrencyBreakdown } from './components/retail-currency-breakdown/retail-currency-breakdown.component';
import { RetailCommonComponent } from './retail-common.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    CitiCommonModule,
    BottomSheetModule,
    ButtonModule
  ],
  declarations: [
    RetailCommonComponent,
    RetailErrorDrawerComponent,
    RetailAmountContainerComponent,
    RetailAccordianComponent,
    Retailbargraph,
    RetailCurrencyBreakdown
  ],
  exports: [RetailErrorDrawerComponent, RetailAmountContainerComponent, RetailAccordianComponent, Retailbargraph, RetailCurrencyBreakdown],
  providers: [

  ]
})
export class RetailCommonModule { }
