'use strict';
var mainApp = angular.module("mainApp", ['ngRoute','app_routes','app.core','app.services','angularModalService','ngSanitize','ngAria','ngAnimate','template-spinner','datepicker']);
console.log("main app js calling first");