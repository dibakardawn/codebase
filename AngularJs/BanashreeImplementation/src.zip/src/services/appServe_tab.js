angular
.module('app.services')
.factory('Tabservices', function ($http) {
    return {
        get: function () {
            console.log("inside function");
            return $http.get('/api/get_tab.json');
        }
    };
});