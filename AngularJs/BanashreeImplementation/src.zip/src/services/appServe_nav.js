angular
.module('app.services')
.factory('navList', function ($http) {
    return {
        get: function () {
            console.log("inside function");
            return $http.get('/api/get_nav.json');
        }
    };
});