	angular
	.module('app.services')
	.controller('navList',function($scope,navList){
		navList.get().then(function(data){
		$scope.navs = data.data.navList;


	});
	});
	