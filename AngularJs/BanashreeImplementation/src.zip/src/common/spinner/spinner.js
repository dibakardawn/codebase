;(function (window) {
  var angular = window.angular;

  

  // constants
  var TEMPLATE_PATH = '/common/spinner/template-spinner.html';
  var TEMPLATE = '';
  TEMPLATE += '<div class="spinner-content">';
  TEMPLATE +=   '<div class="spinner-container">';
  TEMPLATE +=     '<div class="spinner"></div>';
  TEMPLATE +=   '</div>';
  TEMPLATE +=   '<ng-transclude></ng-transclude>';
  TEMPLATE += '</div>';

  // module
  angular.module('template-spinner', ['ngAnimate']);

  // directive
  angular.module('template-spinner').directive('templateSpinner', templateSpinner);
  templateSpinner.$inject = ['$animate'];
  function templateSpinner ($animate) {
    return {
      templateUrl: TEMPLATE_PATH,
      scope: {active: '='},
      transclude: true,
      restrict: 'E',
      link: link
    };

    function link (scope, iElement) {
      scope.$watch('active', statusWatcher);
      function statusWatcher (active) {
        $animate[active ? 'addClass' : 'removeClass'](iElement, 'spinner-active');
      }
    }
  }

  // template
  angular.module('template-spinner').run(spinnerTemplate);
 spinnerTemplate.$inject = ['$templateCache'];
  function spinnerTemplate ($templateCache) {
    $templateCache.put(TEMPLATE_PATH, TEMPLATE);
  }

}.call(this, window));

