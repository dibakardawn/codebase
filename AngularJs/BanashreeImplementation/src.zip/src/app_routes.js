'use strict';

angular.module('app_routes', ['ngRoute'])
	   .config(config);
function config ($routeProvider) {
            $routeProvider
            .when('/CreditCards', {
               templateUrl: 'appContainer/appContainer.html',
               controller: 'creditCardController'
            })
            .when('/CreditCards/Signature', {
               templateUrl: 'partials/Signature.html',
               controller: 'SignatureController'
            })
            
            .when('/CreditCards/Platinum', {
               templateUrl: 'partials/Platinum.html',
               controller: 'PlatinumController'
            })
			
			.when('/CreditCards/Classic', {
               templateUrl: 'partials/Classic.html',
               controller: 'ClassicController'
            })
			
			.when('/CreditCards/ClrPlatinum', {
               templateUrl: 'partials/Clear Platinum.html',
               controller: 'ClrPlatinumController'
            })
			
			.when('/CreditCards/Emirates', {
               templateUrl: 'partials/Emirates.html',
               controller: 'EmiratesController'
            })
			
			.when('/CreditCards/QSignature', {
               templateUrl: 'partials/Qantas Signature.html',
               controller: 'QSignatureController'
            })
			
			.when('/CreditCards/Prestige', {
               templateUrl: 'partials/Prestige.html',
               controller: 'PrestigeController'
            })
            
            .otherwise({
               redirectTo: '/'
            });
};