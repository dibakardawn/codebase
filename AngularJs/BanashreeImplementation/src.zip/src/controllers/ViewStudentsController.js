
    mainApp.controller('ViewStudentsController', function($scope) {
            $scope.message = "This page will be used to display all the students";
			console.log("ViewStudentsController calling");
});