	mainApp.controller('creditCardController', function($scope) {
		$scope.header = "Select Card Diffrent type of credit cards here";
		console.log("creditCardController calling");
		
	});
	angular
	.module('app.services')
	.controller('creditCollections', function($scope,CreditCard) {
		
		CreditCard.get().then(function (creditCards) {
			
        $scope.creditCards = creditCards.data.creditCards;
		
		});
		
	});
	
   angular
   .module('app.core')
   .controller('SignatureController', function($scope,$timeout,Scopes) {
			Scopes.store('SignatureController', $scope);
			$scope.details = "Receive 60,000 reward points on your first spend1. Plus enjoy 0% p.a. for 6 months on balances transfers3 (reverts to cash rate) and a reduced $299 annual fee for life."
			$scope.cardName = "Citibank Signature";
			$scope.card ="component/images/signature.png";
			console.log("signature calling");
			$scope.inputConfig = [
				{
				  label:"First Name",
				  id:'inp',
				  name:'inp',
				  type:"text",
				  placeholder:'placeholder',
				  value :'John'
          
				},
				{
				  label:"last Name",
				  id:'inpL',
				  name:'inpL',
				  type:"text",
				  placeholder:'placeholder',
				  value :'Mark'
          
				}				
			];
			$scope.selectConfig = {
				  label:"Title",
				  type:"select",
				  id:"select",
				  value:"-1",
				  selectOptions:[
					{
					  label: "please select",
					  value: "-1"
					},
					{
					  label: "Mr.",
					  value: "1"
					},
					{
					  label: "Mrs.",
					  value: "2"
					},
					{
					  label: "Miss.",
					  value: "3"
					}
				  ]
			};
			$scope.phnConfig = {
				  label:"Phone Number",
				  id:"phone",
				  name:"phone",
				  value:"-1",
				  inputvalue:"",
				  placeholder:'placeholder',
				  selectOptions:[
					{
					  label: "please select",
					  value: "-1"
					},
					{
					  label: "+91",
					  value: "+91"
					},
					{
					  label: "+92",
					  value: "+92"
					},
					{
					  label: "+93",
					  value: "+93"
					}
				  ]
			};
			 $scope.ctaConfig = {
			  label:"submit",
			  type:"primary",
			  id:"submit"
        
			};
			$scope.dateConfig = {
			  label:"Date of Birth",
			  mindate:"1940/01/01",
			  maxdate:"2016/09/07",
			  format:"yyyy-MM-dd",
			  id:"d1",
			  value:"2016/01/01"
        
			};
			$scope.spinner = {
				active: false,
				on: function () {
					console.log("on")
				  this.active = true;
				},
				off: function () {
				  this.active = false;
				}
			};
			$scope.applynow = function(){
				$scope.spinner.on();
				$timeout(function(){$scope.appliedNow = true}, 3000); 
				$scope.appliedNowDone = true;				
				
				
			};
			$scope.inputSubmitForm = function() {
				debugger;
				$scope.spinner.on();
				$scope.formData = {
				inputConfig: $scope.inputConfig,
				selectConfig: $scope.selectConfig,
				phnConfig: $scope.phnConfig,
				posted: true,
				refNum:0
				};
				console.log("posting data....");
				
		
				
				
				
			};
           
			
	});
	mainApp.controller('SignatureRecapController', function($scope,Scopes) {
		debugger;
			console.log("3rd controller")
		$scope.fromInput = 	Scopes.get('SignatureController').formData;
		$scope.backpage = function(){
			$scope.fromInput.postdata = false;
						
		};
		$scope.confirm = function(){
			$scope.fromInput.confpost = true;
			$scope.refinput = {
				fname: $scope.fromInput.firstname,
				lname: $scope.fromInput.lastname,
				dobs:  $scope.fromInput.dob,
				phns:  $scope.fromInput.phnNum
			};
			$scope.fromInput.refNum = RefNum.getNums($scope.refinput);
			//$scope.fromInput.refNum =
		};
		$scope.backTohome = function(){
			 $("#card_select").show();
			history.back();	
		};
			
		 
			
	});
	angular
	.module("angularModalService")
	.controller('PlatinumController', function($scope,CalcService,ModalService, Scopes) {
			Scopes.store('PlatinumController', $scope);
            $scope.details = "Enjoy 0% p.a. for 24 months on balance transfers (2.5% BT fee applies). Reverts to cash advance rate."
			$scope.cardName = "Citibank platinum";
			$scope.cardTitle = "Citi Rewards Platinum Credit Card Enjoy 60,000 Reward Points when you spend $2,000 within 90 days Rethink banking."
			$scope.card ="component/images/platinum.png";
			$scope.inputdata = {
				"clasname":"hide",
				"title": "Thanks for Applying",
				"applyed":false
			};
			
			$scope.onlyChar = "[a-zA-Z ]*$";
			$scope.phoneNum = "^([0-9]{3}([-\s]?[0-9]{8})?)$";
			
			$scope.showYesNo = function() {
				ModalService.showModal({
				  templateUrl: "partials/popup.html",
				   controller: "modalController"
				}).then(function(modal) {
				  modal.element.modal();
				  modal.close.then(function(result) {
					  console.log(result);
					  $scope.resultTab = result; 
					$scope.yesNoResult = result ? "You said Yes" : "You said No";
				  });
				});

			};
			
            $scope.applynowSce = function(show) {
				console.log("ss");
				$scope.inputdata.applyed = true;
				
				var wet = $scope.inputdata.clasname = "show";
               $scope.applynowSce = CalcService.applynowSce(wet);
			   if($scope.inputdata.applyed){
				   $("#card_select").hide();
			   }
            };
			
			
			/*$scope.$on('submitForm', function (event, args) {
				console.log("posting data....");
				$scope.formData = {
				firstname: $scope.firstName,
				lastname: $scope.lastName,
				dob: $scope.date.getDate()+"/"+($scope.date.getMonth()+1)+"/"+$scope.date.getFullYear(),
				phnNum: $scope.phNum,
				email: $scope.emails,
				postdata: true	
				};
				formData = $scope.formData;
				console.log(formData);
				var wet = $scope.inputdata.clasname = "show";
				$scope.submitForm = CalcService.applynowSce(wet);
			});*/

			

			$scope.submitForm = function() {
				console.log("posting data....");
				$scope.formData = {
				firstname: $scope.firstName,
				lastname: $scope.lastName,
				dob: $scope.date.getDate()+"/"+($scope.date.getMonth()+1)+"/"+$scope.date.getFullYear(),
				phnNum: $scope.phNum,
				email: $scope.emails,
				postdata: true,
				confpost: false,
				refNum:0
				};
				formData = $scope.formData;
				console.log(formData);
				
				
				
			};
           
			console.log("platinum calling");
			
	});
	mainApp.controller('modalController', ['$scope', 'close', function($scope, close) {
		$scope.resultTab = '';
		 $scope.close = function(result) {
			resultTab  = result;
			close(result, 500); 
		 };
		 

	}]);
	angular
	.module('app.services')
	.controller('TabsCtrl', function($scope,Tabservices,$sce) {
	$scope.$sce = $sce;
		Tabservices.get().then(function (tabservices) {
		
		//$scope.bindHTML = $sce.trustAsHtml(tabservices.data);		
        $scope.tabservices =  tabservices.data.tabdata;
		$scope.tabs =  tabservices.data.tabs;
		$scope.valuSeries =  tabservices.data.valuSeries;
		
		});
		
    $scope.currentTab = 'one.html';

    $scope.onClickTab = function (tab) {
        $scope.currentTab = tab.url;
    }
    
    $scope.isActiveTab = function(tabUrl) {
        return tabUrl == $scope.currentTab;
    }
	$scope.bindHtml = function(value) {
		return $sce.trustAsHtml(value);
	};
});
	mainApp.directive('tooltip', function(){
		return {
			restrict: 'A',
			link: function(scope, element, attrs){
				$(element).hover(function(){
					// on mouseenter
					$(element).tooltip('show');
				}, function(){
					// on mouseleave
					$(element).tooltip('hide');
				});
			}
		};
	});
	mainApp.controller('PlatinumRecapController', function($scope,Scopes,RefNum) {
			console.log("3rd controller")
		$scope.fromInput = 	Scopes.get('PlatinumController').formData;
		$scope.backpage = function(){
			$scope.fromInput.postdata = false;
						
		};
		$scope.confirm = function(){
			$scope.fromInput.confpost = true;
			$scope.refinput = {
				fname: $scope.fromInput.firstname,
				lname: $scope.fromInput.lastname,
				dobs:  $scope.fromInput.dob,
				phns:  $scope.fromInput.phnNum
			};
			$scope.fromInput.refNum = RefNum.getNums($scope.refinput);
			//$scope.fromInput.refNum =
		};
		$scope.backTohome = function(){
			 $("#card_select").show();
			history.back();	
		};
			
		 
			
	});
	
	mainApp.controller('formsController', function($scope){
		
		$scope.checked = false;
	   $scope.toggleCheckbox = function(){
		 $scope.checked = !$scope.checked;
	   }
	})
	.directive('someCheckbox', function(){
	return {
     restrict: 'E',
     link: function($scope, $el, $attrs) {
		
       $el.on('keydown', function(event){
         event.preventDefault();
         if(event.keyCode === 32 || event.keyCode === 13){
           $el.toggleCheckbox();
           $scope.$apply();
         }
       });
     }
   }
	})
	.directive('showAttrs', function() {
   return function($scope, $el, $attrs) {
     var pre = document.createElement('pre');
     $el.after(pre);
     $scope.$watch(function() {
       var $attrs = {};
       Array.prototype.slice.call($el[0].attributes, 0).forEach(function(item) {
         if (item.name !== 'show-$attrs') {
           $attrs[item.name] = item.value;
         }
       });
       return $attrs;
     }, function(newAttrs, oldAttrs) {
       pre.textContent = JSON.stringify(newAttrs, null, 2);
     }, true);
   }
 });
 mainApp.controller('MainCtrl', function($scope) {
  $scope.newObject = {};
  $scope.items = [{name:'foo'}, {name:'bar'}, {name:'baz'}];
 
});
 mainApp.controller('checkboxCtrl', function($scope){
		$scope.array = [1, 3];
        $scope.array_ = angular.copy($scope.array);
        $scope.list = [{
            "id": 1,
            "value": "one",
			
        }, {
            "id": 2,
            "value": "two",
			
        }, {
            "id": 3,
            "value": "three",
			
        }];
		
      
		$scope.checked = false;
        $scope.toggleCheckbox1 = function (id) {
		
			if (id.checked === true){
				id.checked = false;
			}else{
				id.checked = true;
			}
			/*
			$scope.checked = !($scope.list[id-1].checked);  
			console.log('clicked');
			*/
        };
		
	})
	.directive("checkboxgroup", function() {
        return {
            restrict: "A",
            link: function(scope, elem, attrs) {
				debugger;
                // Determine initial checked boxes
                if (scope.array.indexOf(scope.item.id) !== -1) {
                    elem[0].checked = true;
                }

                // Update array on click
                elem.bind('click', function() {
                    var index = scope.array.indexOf(scope.item.id);
                    // Add if checked
                    if (elem[0].checked) {
                        if (index === -1) scope.array.push(scope.item.id);
                    }
                    // Remove if unchecked
                    else {
                        if (index !== -1) scope.array.splice(index, 1);
                    }
                    // Sort and update DOM display
                    scope.$apply(scope.array.sort(function(a, b) {
                        return a - b
                    }));
                });
            }
        }
    });
	
	
	mainApp.controller('ClassicController', function($scope) {
            $scope.details = "Save with 0% p.a. for 18 months on balance transfers1. Reverts to cash advance rate."
			$scope.cardName = "Citibank Classic";
			$scope.card ="component/images/classic.png";
			console.log("classic calling");
			
	});
	
	mainApp.controller('ClrPlatinumController', function($scope) {
            $scope.details = "Save with 0% p.a. for up to 9 months on purchases and balance transfers1. Plus, enjoy a half-price annual fee of $49 in your first year2."
			$scope.cardName = "Citibank clear Platinum";
			$scope.card ="component/images/clear-platinum.png";
			console.log("clear-platinum calling");
			
	});
	
	mainApp.controller('EmiratesController', function($scope) {
            $scope.details = "Receive 40,000 bonus Skywards Miles on your first spend1. Plus enjoy a half-price annual fee in your first year2."
			$scope.cardName = "Citibank Emirates";
			$scope.card ="component/images/emirates.png";
			console.log("emirates calling");
			
	});
	
	mainApp.controller('QSignatureController', function($scope) {
            $scope.details = "Receive 50,000 bonus Qantas points on your first spend1, plus enjoy a reduced $299 annual fee for life."
			$scope.cardName = "Citi Qantas Signature";
			$scope.card ="component/images/simplicity.png";
			console.log("classic calling");
			
	});
	
	mainApp.controller('PrestigeController', function($scope) {
            $scope.details = "Receive 70,000 bonus reward points on your first spend1 plus 0% p.a. for 6 months on balance transfers2 (reverts to cash rate)."
			$scope.cardName = "Citibank Prestige";
			$scope.card ="component/images/prestige.png";
			console.log("prestige calling");
			
	});
	mainApp.factory('applyNow', function() {
            var factory = {};
            
            factory.apply = function(a) {
				
               return a;
            }
            return factory;
    });
         
    mainApp.service('CalcService', function(applyNow){
            this.applynowSce = function(a) {
               return applyNow.apply(a);
            }
    });
	mainApp.factory('getNum', function() {
            var factory = {};
            
            factory.apply = function(a) {
			a = (a.fname.charAt(0).toUpperCase())+(a.dobs.split('/').join(a.fname.charAt(2)))+(a.phns.slice(8,a.phns.length))+(a.lname.charAt(a.lname.length-1).toUpperCase());
               return a;
            }
            return factory;
    });
	mainApp.service('RefNum', function(getNum){
            this.getNums = function(a) {
               return getNum.apply(a);
            }
    });
    mainApp.run(function ($rootScope) {
		$rootScope.$on('scope.stored', function (event, data) {
			console.log("scope.stored", data);
		});
	});
	mainApp.factory('Scopes', function ($rootScope) {
		var mem = {};
	 
		return {
			store: function (key, value) {
				$rootScope.$emit('scope.stored', key);
				mem[key] = value;
			},
			get: function (key) {
				return mem[key];
			}
		};
	});    
    mainApp.service('modalServe', function(getNum){
            this.getNums = function(a) {
               return getNum.apply(a);
            }
    });     
