
// Code goes here

angular
    .module('app.core')
    .directive('textControl',function() {
    return {
		
            restrict:  'E',
            scope: {
              'config' : '='
            },
            templateUrl: 'utilityControl/text-control-template.html'
          }
	})
	.directive('selectControl',function(){
          return {
            restrict:  'E',
            scope: {
              'config' : '='
            },
            templateUrl: 'utilityControl/select-control-template.html'
          }
	})
	.directive('phoneControl',function(){
          return {
            restrict:  'E',
            scope: {
              'config' : '=',
			  
            },

            templateUrl: 'utilityControl/phone-control-template.html'
          }
	})
	.directive('buttonControl',function(){
          return {
            restrict:  'E',
            scope: {
              'config' : '=',
			  'clicked' : '&dataClicked'
            },
            templateUrl: 'utilityControl/button-control-template.html'
          }
	})
	.directive('hrlineControl',function(){
          return {
            restrict:  'E',
			templateUrl: 'utilityControl/hrline-control-template.html'
          }
	})
	.directive('dateControl',function(){
          return {
            restrict:  'E',
			scope: {
              'config' : '='
			  
            },
			templateUrl: 'utilityControl/date-control-template.html'
          }
	})

