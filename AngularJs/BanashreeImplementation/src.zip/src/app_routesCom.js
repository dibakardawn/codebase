'use strict';

angular.module('app_routesCom', ['ngRoute'])
	   .config(config);
function config ($routeProvider) {
            $routeProvider
            
            .when('/Home', {
               templateUrl: 'partials/Home.html',
               controller: 'SignatureController'
            })
            
            .when('/CreditCards', {
               templateUrl: 'appContainer/appContainer.html',
               controller: 'creditCardController'
            })
			
			
            .otherwise({
               redirectTo: '/'
            });
};