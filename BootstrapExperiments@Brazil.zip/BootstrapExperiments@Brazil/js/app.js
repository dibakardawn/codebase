$(document).ready(function(){
    //alert(1);
	if($(document).width() === 789 || $(document).width() < 789){
		$("#toggleBtnBlackHeader, #toggleBtnGoldHeader").find("span.icon-bar").css("background-color", "#fff");
		$(".navbar-brand").show();
		$("#tagheader").css("padding-left", "10px");
		$("#mobhambergarMenu").show();
		$("#leftMenu").addClass("stylishMenu").hide();
		$("#mobhambergarMenu").bind("click", function() {
			$("#leftMenu").toggle("fast");
		});
	}else{
		$(".navbar-brand").hide();
		$("#mobhambergarMenu").remove();
	}
	
	/*$("body").click(function(e) {
	  alert(e.target.id);
      if(e.target.id !== ''){
        $("#leftMenu").hide();
      }      
    });*/
	
});